import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { Plus, Search } from "lucide-react";
import AsyncWrapper from "../utils/AsyncWrapper";
import { useFetchBreakingNews } from "../hooks/news";
import { formatDate } from "../utils/utils";
import Pagination from "../utils/Pagination";
import PopUp from "../utils/PopUp";
import Confirmation from "../utils/Confirmation";
import EditBreakingNewsHandler from "../components/breakingnews/EditBreakingNewsHandler";
import AddBreakingNews from "../components/breakingnews/AddBreakingNews";
import httpClient from "../api/httpClient";
import AddButton from "../components/AddButton";

const BreakingNews = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [finalSearch, setFinalSearch] = useState("");
  const [page, setPage] = useState(1);
  const [id, setId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const itemsPerPage = 10;
  const [addBreakingNews, setAddBreakingNews] = useState(false);
  const [editBreakingNews, setEditBreakingNews] = useState(false);
  const [selectedNews, setSelectedNews] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const scrollRef = useRef(null);

  const handleSubmitSearch = (e) => {
    e.preventDefault();
    setFinalSearch(search);
    refetch();
  };
  const { isPending, data, isError, error, refetch } = useFetchBreakingNews({
    page,
    search: finalSearch,
    limit: itemsPerPage,
  });
  const handleDelete = async (e) => {
    if (isDeleting) return;
    setIsDeleting(true);
    if (!id) return toast.error("Try again.");
    let loadingToast = toast.loading("Deleting...");
    try {
      const { data } = await httpClient.delete(`delete-breaking-news/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("News Deleted Successfully");
      refetch();
      setIsDeleting(false);
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to delete news");
      console.log(err);
      setIsDeleting(false);
      setIsModalOpen(false);
    }
  };

  return (
    <div className="mx-auto p-1 sm:p-3 bg-surface rounded-md">
      <AddButton addfun={() => setAddBreakingNews(true)} />
      <div className="flex justify-between max-md:flex-col items-center gap-4 mb-2">
        <form
          onSubmit={handleSubmitSearch}
          className="border-2 rounded-sm w-full sm:w-60 flex  justify-between items-center"
        >
          <input
            type="text"
            placeholder="Search News"
            // onKeyDown={handleSubmitSearch}
            // onSubmit={handleSubmitSearch}
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
            }}
            className="border-none outline-none max-sm:p-1 p-1 rounded"
          />
          <Search size={25} className="max-sm:pr-1 p-1" />
        </form>
      </div>
      <div
        className="space-y-3 h-[calc(100vh-165px)] sm:h-[calc(100vh-190px)] md:h-[calc(100vh-220px)] overflow-auto p-0.5 md:p-2"
        ref={scrollRef}
      >
        <AsyncWrapper isError={isError} isPending={isPending} error={error}>
          {data?.news?.length ? (
            data?.news?.map((item, index) => (
              <div
                key={index}
                className="grid sm:grid-cols-7 lg:grid-cols-6 gap-2 items-center p-1 max-sm:pb-2 sm:p-2 rounded shadow-card dark:border-b"
                // style={{boxShadow: `rgba(100, 100, 111, 0.2) 0px 7px 29px 0px`}}
              >
                <div className="flex-1 sm:col-span-5">
                  <h3 className="text-lg line-clamp-1">
                    {item.title}
                  </h3>
                  <div className="flex max-sm:flex-col justify-start gap-y-1 gap-x-3 lg:gap-x-8">
                    <p className="text-[16px] text-fg-subtle">
                      <span className="text-fg">
                        Created On:
                      </span>{" "}
                      {formatDate(item.createdAt)}
                    </p>

                    <p className="text-lg text-gray">
                      <span className="text-fg">
                        Reporter
                      </span>
                      <Link className="text-primary border-b border-blue ml-2 font-light">
                        @{item?.author?.username}
                      </Link>
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 mt-2 justify-end">
                  <button
                    className="bg-primary  text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                    onClick={() => {
                      setSelectedNews(item);
                      setEditBreakingNews(true);
                    }}
                  >
                    Edit
                  </button>
                  <button
                    className="bg-accent text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                    onClick={() => {
                      setIsModalOpen(true);
                      setId(item?._id);
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-1 items-center justify-center h-full">
              <h5 className="text-3xl text-fg-muted hindi-font">
                कोई खबर उपलब्ध नहीं है
              </h5>
            </div>
          )}
        </AsyncWrapper>
      </div>
      <div className="flex justify-between mt-4">
        <Pagination
          totalItems={data?.total}
          itemsPerPage={itemsPerPage}
          defaultCurrent={1}
          current={page}
          onChange={(val) => setPage(val)}
          isLoading={isPending}
        />
      </div>
      <PopUp
        isOpen={addBreakingNews}
        onClose={() => setAddBreakingNews(false)}
        heading="Add Breaking News"
      >
        <AddBreakingNews
          setAddBreakingNews={setAddBreakingNews}
          refetch={refetch}
        />
      </PopUp>
      <PopUp
        isOpen={editBreakingNews}
        onClose={() => setEditBreakingNews(false)}
        heading="Edit Breaking News"
      >
        <EditBreakingNewsHandler
          news={selectedNews}
          setEditBreakingNews={setEditBreakingNews}
          refetch={refetch}
        />
      </PopUp>

      <Confirmation
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handleDelete}
        description="Are you sure you want to delete this news?"
        title="Delete News"
        btnDanger={true}
        btnTitle="Delete"
      />
    </div>
  );
};

export default BreakingNews;
