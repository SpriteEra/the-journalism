import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { Plus, Search } from "lucide-react";
import AsyncWrapper from "../utils/AsyncWrapper";
import { useFetchBreakingNews } from "../hooks/news";
import { formatDate } from "../utils/utils";
import Pagination from "../utils/Pagination";
import PopUp from "../utils/PopUp";
import Confirmation from "../utils/Confirmation";
import EditBreakingNewsHandler from "../components/breakingnews/EditBreakingNewsHandler";
import AddBreakingNews from "../components/breakingnews/AddBreakingNews";
import httpClient from "../api/httpClient";
import AddButton from "../components/AddButton";
import { useFetchTitleAds } from "../hooks/ads";
import EditTitleAds from "../components/title-ads/EditTitleAds";
import AddAdvertisementNews from "../components/title-ads/AddAdvertisementNews";

const TitleAds = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [finalSearch, setFinalSearch] = useState("");
  const [page, setPage] = useState(1);
  const [id, setId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const itemsPerPage = 6;
  const [addBreakingNews, setAddBreakingNews] = useState(false);
  const [editBreakingNews, setEditBreakingNews] = useState(false);
  const [selectedNews, setSelectedNews] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isRenewing, setIsRenewing] = useState(false);

  const [confirmationData, setConfirmationData] = useState({
    title: "",
    bg: "",
    button: "",
    fun: null,
    id: null,
  });

  const scrollRef = useRef(null);

  const handleSubmitSearch = (e) => {
    e.preventDefault();
    setFinalSearch(search);
    refetch();
  };
  const { isPending, data, isError, error, refetch } = useFetchTitleAds({
    page,
    limit: itemsPerPage,
    search: finalSearch,
  });
  const handleDelete = async (e) => {
    let loadingToast = toast.loading("Deleting...");
    if (!id) return;
    try {
      const { data } = await httpClient.delete(`delete-title-ads/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("Advertisement Deleted Successfully");
      refetch();
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to delete news");
      console.log(err);
      setIsModalOpen(false);
    }
  };
  const ExtendExpiry = async (e) => {
    e.target.disabled = true;
    let loadingToast = toast.loading("Extending...");
    if (!id) return;
    try {
      const { data } = await httpClient.put(`extend-expiry/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("Advertisement Extended Successfully");
      refetch();
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to extend news");
      console.log(err);
      setIsModalOpen(false);
    }
  };

  const RenewPlan = async (e) => {
    e.target.disabled = true;
    let loadingToast = toast.loading("Renewing...");
    if (!id) return;
    try {
      const { data } = await httpClient.put(`renew-expiry/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("Advertisement Renewed Successfully");
      refetch();
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to renew news");
      console.log(err);
      setIsModalOpen(false);
    }
  };

  return (
    <div className="mx-auto p-3 bg-surface rounded-md">
      <AddButton addfun={() => setAddBreakingNews(true)} />
      <div className="flex justify-between max-md:flex-col items-center gap-4 mb-2">
        <form
          onSubmit={handleSubmitSearch}
          className="border-2 rounded-sm w-full sm:w-60 flex  justify-between items-center"
        >
          <input
            type="text"
            placeholder="Search News"
            // onKeyDown={handleSubmitSearch}
            // onSubmit={handleSubmitSearch}
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
            }}
            className="border-none outline-none max-sm:p-1 p-1 rounded"
          />
          <Search size={25} className="max-sm:pr-1 p-1" />
        </form>
      </div>
      <div
        className="space-y-3 h-[calc(100vh-165px)] sm:h-[calc(100vh-190px)] md:h-[calc(100vh-220px)] overflow-auto p-0.5 md:p-2"
        ref={scrollRef}
      >
        <AsyncWrapper isError={isError} isPending={isPending} error={error}>
          {data?.ads?.length ? (
            data?.ads?.map((item, index) => (
              <div
                key={index}
                className="grid sm:grid-cols-7 lg:grid-cols-6 gap-2 items-center p-1 max-sm:pb-2 sm:p-2 rounded shadow-card dark:border-b"
                // style={{boxShadow: `rgba(100, 100, 111, 0.2) 0px 7px 29px 0px`}}
              >
                <div className="flex-1 sm:col-span-5">
                  <h3 className="text-lg line-clamp-1">
                    {item.title}
                  </h3>
                  <div className="flex justify-start md:gap-8 flex-wrap">
                    {item?.link && (
                      <a
                        href={item?.link}
                        target="_blanck"
                        className="text-fg-muted hover:underline "
                      >
                        <span className="font-medium text-accent">
                          Link :
                        </span>{" "}
                        {item?.link}
                      </a>
                    )}
                    {item?.email && (
                      <p className="text-fg-muted">
                        <span className="font-medium text-accent">
                          Email :
                        </span>{" "}
                        {item?.email}
                      </p>
                    )}
                  </div>
                  <div className="flex justify-start gap-8 flex-wrap">
                    <p className="text-fg-muted">
                      <span className="font-medium text-primary">
                        Created On:
                      </span>{" "}
                      {formatDate(item?.createdAt)}
                    </p>
                    <p className="text-fg-muted">
                      <span className="font-medium text-primary">
                        Expire On:
                      </span>{" "}
                      {formatDate(item?.expireDate)}
                    </p>
                    <p className="text-fg-muted">
                      <span className="font-medium text-primary">
                        Created By:
                      </span>{" "}
                      @{item?.author?.username}
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 mt-2 justify-end">
                  <button
                    className="bg-primary  text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                    onClick={() => {
                      setSelectedNews(item);
                      setEditBreakingNews(true);
                    }}
                  >
                    Edit
                  </button>

                  {!item.isExpired && (
                    <button
                      className="bg-success text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() => {
                        setIsModalOpen(true);
                        setId(item?._id);
                        setConfirmationData({
                          ...confirmationData,
                          title:
                            "Are you sure, you want to extend expiry for this advertisement?",
                          bg: "bg-success",
                          button: "Extend",
                          fun: ExtendExpiry,
                          id: 3,
                        });
                      }}
                    >
                      Extend
                    </button>
                  )}
                  {item.isExpired && (
                    <button
                      className="bg-success text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() => {
                        setIsModalOpen(true);
                        setId(item?._id);
                        setConfirmationData({
                          title:
                            "Are you sure, you want to renew this advertisement?",
                          bg: "bg-red",
                          button: "Renew",
                          fun: RenewPlan,
                          id: 2,
                        });
                      }}
                    >
                      Renew
                    </button>
                  )}

                  <button
                    className="bg-accent text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                    onClick={() => {
                      setIsModalOpen(true);
                      setId(item?._id);
                      setConfirmationData({
                        title:
                          "Are you sure, you want to delete this advertisement?",
                        bg: "bg-red",
                        button: "Renew",
                        fun: RenewPlan,
                        id: 1,
                      });
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-1 items-center justify-center h-full">
              <h5 className="text-3xl text-fg-muted hindi-font">
                कोई खबर उपलब्ध नहीं है
              </h5>
            </div>
          )}
        </AsyncWrapper>
      </div>
      <div className="flex justify-between mt-4">
        <Pagination
          totalItems={0}
          itemsPerPage={10}
          defaultCurrent={1}
          current={page}
          onChange={(val) => setPage(val)}
          isLoading={false}
        />
      </div>
      <PopUp
        isOpen={addBreakingNews}
        onClose={() => setAddBreakingNews(false)}
        heading="Add Breaking News"
      >
        <AddAdvertisementNews
          setAddBreakingNews={setAddBreakingNews}
          refetch={refetch}
        />
      </PopUp>
      <PopUp
        isOpen={editBreakingNews}
        onClose={() => setEditBreakingNews(false)}
        heading="Edit Title Ads"
      >
        <EditTitleAds
          news={selectedNews}
          setEditBreakingNews={setEditBreakingNews}
          refetch={refetch}
        />
      </PopUp>
      {confirmationData.id === 1 && (
        <Confirmation
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={handleDelete}
          description="Are you sure you want to delete this ads?"
          title="Delete Ads"
          btnDanger={true}
          btnTitle="Delete"
        />
      )}
      {confirmationData.id === 2 && (
        <Confirmation
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={RenewPlan}
          description={confirmationData.title}
          title="Renew Ads"
          btnTitle="Renew Now"
        />
      )}

      {confirmationData.id === 3 && (
        <Confirmation
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={ExtendExpiry}
          description={confirmationData.title}
          title="Extent Expiry"
          btnTitle="Extent"
        />
      )}
    </div>
  );
};

export default TitleAds;
