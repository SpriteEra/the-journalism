import { useState } from "react";
import { User, Mail, FileText, Lock, Edit2, Bell } from "lucide-react";
import ThemeSettings from "../components/ThemeSettings";
import { useFetchProfile } from "../hooks/user";
import AsyncWrapper from "../utils/AsyncWrapper";
import PopUp from "../utils/PopUp";
import UpdatePasswordUser from "../components/UpdatePasswordUser";
import NotificationSettings from "../components/NotificationSettings";
function formatDate(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}
const Profile = () => {
  // Password update states
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const { data, isPending, isError, error } = useFetchProfile();

  return (
    <div className="mx-auto p-3 bg-surface rounded-md">
      <AsyncWrapper isPending={isPending} isError={isError} error={error}>
        <div className="max-w-4xl mx-auto">
          <div className="mx-auto p-6 bg-surface rounded-lg shadow-lg mb-6">
            <h1 className="text-2xl sm:text-3xl font-bold text-fg mb-2">
              {data?.fullName || "No data available"}
            </h1>
            <p className="text-fg-muted text-lg">
              @{data?.username}
            </p>
            <p className="text-fg-subtle">
              Member since {formatDate(data?.createdAt)}
            </p>
          </div>

          <div className="grid lg:grid-cols-5 gap-6">
            {/* Account Information */}
            <div className="col-span-3 p-3 sm:p-6 bg-surface rounded-lg shadow-lg">
              <h2 className="text-xl sm:text-2xl font-bold text-fg mb-6 flex items-center gap-2">
                <User className="text-primary" size={24} />
                Account Information
              </h2>

              <div className="space-y-3 sm:space-y-6">
                {/* Username */}
                <div className="flex items-center gap-4 p-4 bg-surface-2 rounded-lg">
                  <div className="bg-primary-soft p-3 rounded-full">
                    <User
                      className="text-primary"
                      size={20}
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-fg-subtle">
                      Username
                    </p>
                    <p className="text-lg font-semibold text-fg">
                      {data?.username}
                    </p>
                  </div>
                </div>

                {/* Full Name */}
                <div className="flex items-center gap-4 p-4 bg-surface-2 rounded-lg">
                  <div className="bg-success-soft p-3 rounded-full">
                    <Edit2
                      className="text-success"
                      size={20}
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-fg-subtle">
                      Full Name
                    </p>
                    <p className="text-lg font-semibold text-fg">
                      {data?.fullName || "No full name provided"}
                    </p>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-center gap-4 p-4 bg-surface-2 rounded-lg">
                  <div className="bg-primary-soft p-3 rounded-full">
                    <Mail
                      className="text-primary"
                      size={20}
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-fg-subtle">
                      Email
                    </p>
                    <p className="text-lg font-semibold text-fg">
                      {data?.email}
                    </p>
                  </div>
                </div>

                {/* News Count */}
                {/* <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-warning-soft to-danger-soft rounded-lg border border-warning/30">
                  <div className="bg-warning-soft p-3 rounded-full">
                    <FileText
                      className="text-warning"
                      size={20}
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-fg-subtle">
                      Total News Articles
                    </p>
                    <p className="text-2xl font-bold text-warning">
                      {data?.account_info?.total_news || 0}
                    </p>
                  </div>
                </div> */}
              </div>
            </div>

            <div className="space-y-6 col-span-2 bggre">
              {/* Theme Settings */}
              <ThemeSettings />
              {/* <NotificationSettings /> */}

              {/* Password Update Section */}
              <div className="p-6 bg-surface rounded-lg shadow-lg">
                <h2 className="text-xl sm:text-2xl font-bold text-fg mb-6 flex items-center gap-2">
                  <Bell className="text-primary" size={24} />
                  Notification Settings
                </h2>
                <div className="text-center py-8">
                  <button
                    onClick={() => setShowNotification(true)}
                    className="bg-primary hover:bg-primary-hover text-paper px-6 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center gap-2 mx-auto"
                  >
                    <Bell size={20} />
                    Manage Notifications
                  </button>
                </div>
              </div>
              <div className="p-6 bg-surface rounded-lg shadow-lg">
                <h2 className="text-xl sm:text-2xl font-bold text-fg mb-6 flex items-center gap-2">
                  <Lock className="text-danger" size={24} />
                  Security Settings
                </h2>
                <div className="text-center py-8">
                  <button
                    onClick={() => setShowPasswordForm(true)}
                    className="bg-danger hover:bg-danger-hover text-paper px-6 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center gap-2 mx-auto"
                  >
                    <Lock size={20} />
                    Update Password
                  </button>
                </div>
              </div>
            </div>
          </div>
          <PopUp
            heading="Edit Password"
            isOpen={showPasswordForm}
            onClose={() => setShowPasswordForm(false)}
          >
            <UpdatePasswordUser onclose={() => setShowPasswordForm(false)} />
          </PopUp>
          <PopUp
            heading="Notification Settings"
            isOpen={showNotification}
            onClose={() => setShowNotification(false)}
          >
            <NotificationSettings onclose={() => setShowNotification(false)} />
          </PopUp>
        </div>
      </AsyncWrapper>
    </div>
  );
};

export default Profile;
