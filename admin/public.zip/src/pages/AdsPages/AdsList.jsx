import { useState, useEffect } from "react";
import { Reorder } from "framer-motion";
import Tooltip from "../../components/common/Tooltip/Tooltip";
import toast from "react-hot-toast";
import httpClient from "../../api/httpClient";
import { useNavigate } from "react-router-dom";
import Confirmation from "../../utils/Confirmation";
import { formatDate } from "../../utils/utils";
import AdsUploader from "./AdsUploader";
import PopUp from "../../utils/PopUp";

/* ---------- component ---------- */
const AdsList = ({ setShowAdd, ads = [], setAds, refetch, adType = 2 }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [changeHappen, setChangeHappen] = useState(false);
  const [confirmationData, setConfirmationData] = useState({
    title: "",
    bg: "",
    button: "",
    fun: null,
    id: null,
  });
  const [selectedItem, setSelectedItem] = useState(null);
  const [isEdit, setIsEdit] = useState(false);
  const [id, setId] = useState(null);

  /* derived state for reorder */
  const [ids, setIds] = useState([]);
  const [map, setMap] = useState({});
  const navigate = useNavigate();

  const RenewPlan = async (e) => {
    e.target.disabled = true;
    let loadingToast = toast.loading("Renewing...");
    if (!id) return;
    try {
      const { data } = await httpClient.put(`renew-main-expiry/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("Advertisement Renewed Successfully");
      refetch();
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to renew news");
      console.log(err);
      setIsModalOpen(false);
    }
  };

  const ExtendExpiry = async (e) => {
    e.target.disabled = true;
    let loadingToast = toast.loading("Extending...");
    if (!id) return;
    try {
      const { data } = await httpClient.put(`extend-main-expiry/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("Advertisement Extended Successfully");
      refetch();
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to extend news");
      console.log(err);
      setIsModalOpen(false);
    }
  };

  /* build id map whenever ads changes */
  useEffect(() => {
    setIds(ads.map((a) => a._id));
    const m = {};
    ads.forEach((a) => (m[a._id] = a));
    setMap(m);
  }, [ads]);

  /* ---------- CRUD ---------- */
  const handleDelete = async () => {
    if (!id) return;
    const loading = toast.loading("Deleting...");
    try {
      await httpClient.delete(`/delete-ads/${id}`);
      setAds(ads.filter((ad) => ad._id !== id));
      toast.success("Advertisement deleted");
    } catch (e) {
      toast.error("Delete failed");
    } finally {
      toast.dismiss(loading);
      setIsModalOpen(false);
    }
  };

  const handleEdit = (id) => {
    navigate("?add_id=" + id);
    setShowAdd(2);
  };

  /* ---------- reorder ---------- */
  const handleReorder = (newIds) => {
    setIds(newIds);
    setAds(newIds.map((id) => map[id]));
    setChangeHappen(true);
  };

  const persistOrder = async (e) => {
    e.target.disabled = true;
    try {
      await httpClient.post("/ads/update-order", { orderedAds: ads });
      toast.success("Order updated");
      setChangeHappen(false);
    } catch (e) {
      toast.error("Update failed");
    } finally {
      e.target.disabled = false;
    }
  };

  /* ---------- add new ---------- */
  const handleAdd = () => {
    if (ads.length >= 5) {
      toast.error("You can only add 5 Advertisement images");
      return;
    }
    setShowAdd(2);
  };

  /* ---------- render ---------- */
  return (
    <>
      {/* drag list */}
      {ads.length === 0 ? (
        <div className="min-h-32 flex items-center justify-center">
          <h4 className="text-lg sm:text-2xl">
            No Ads Available
          </h4>
        </div>
      ) : (
        <Reorder.Group
          axis="y"
          values={ids}
          onReorder={handleReorder}
          className="space-y-3 mt-2"
        >
          {ids.map((id) => {
            const ad = map[id];
            return (
              <Reorder.Item
                key={id}
                value={id}
                className="grid sm:grid-cols-7 lg:grid-cols-6 gap-2 items-center p-1 max-sm:pb-2 sm:p-2 rounded shadow-card dark:border-b"
                whileDrag={{
                  scale: 1.02,
                  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                }}
              >
                <div className="flex-1 sm:col-span-5 gap-2">
                  <div className="flex gap-2">
                    <img
                      src={ad?.banner?.url}
                      alt="Advertisement"
                      className="w-28 h-20 object-cover rounded-md pointer-events-none"
                    />
                    <div className="flex justify-start flex-col flex-wrap">
                      <p className="text-fg-muted text-sm">
                        <span className="font-medium text-primary">
                          Created On:
                        </span>{" "}
                        {formatDate(ad?.createdAt)}
                      </p>
                      <p className="text-fg-muted text-sm">
                        <span className="font-medium text-primary">
                          Expire On:
                        </span>{" "}
                        {formatDate(ad?.expireDate)}
                      </p>
                      <p className="text-fg-muted text-sm">
                        <span className="font-medium text-primary">
                          Created By:
                        </span>{" "}
                        @{ad?.author?.username}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {ad?.link && (
                      <a
                        href={ad?.link}
                        target="_blank"
                        className="text-fg-muted hover:underline "
                      >
                        <span className="font-medium text-accent">
                          Link :
                        </span>{" "}
                        {ad?.link}
                      </a>
                    )}
                    {ad?.email && (
                      <p className="text-fg-muted">
                        <span className="font-medium text-accent">
                          Email :
                        </span>{" "}
                        {ad?.email}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex gap-4 mt-2 justify-end">
                  <button
                    className="bg-primary  text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                    onClick={() => {
                      setSelectedItem(ad);
                      setIsEdit(true);
                    }}
                  >
                    Edit
                  </button>

                  {!ad.isExpired && (
                    <button
                      className="bg-success text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() => {
                        setIsModalOpen(true);
                        setId(ad?._id);
                        setConfirmationData({
                          ...confirmationData,
                          title:
                            "Are you sure, you want to extend expiry for this advertisement by 30 days?",
                          bg: "bg-success",
                          button: "Extend",
                          fun: ExtendExpiry,
                          id: 3,
                        });
                      }}
                    >
                      Extend
                    </button>
                  )}
                  {ad.isExpired && (
                    <button
                      className="bg-success text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() => {
                        setIsModalOpen(true);
                        setId(ad?._id);
                        setConfirmationData({
                          title:
                            "Are you sure, you want to renew this advertisement?",
                          bg: "bg-red",
                          button: "Renew",
                          fun: RenewPlan,
                          id: 2,
                        });
                      }}
                    >
                      Renew
                    </button>
                  )}

                  <button
                    className="bg-accent text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                    onClick={() => {
                      setIsModalOpen(true);
                      setId(ad?._id);
                      setConfirmationData({
                        title:
                          "Are you sure, you want to delete this advertisement?",
                        bg: "bg-red",
                        button: "Renew",
                        fun: RenewPlan,
                        id: 1,
                      });
                    }}
                  >
                    Delete
                  </button>
                </div>
              </Reorder.Item>
            );
          })}
        </Reorder.Group>
      )}

      {/* persist button */}
      {changeHappen && (
        <Tooltip text="Click to update">
          <button className="btn-red mt-2" onClick={persistOrder}>
            Update
          </button>
        </Tooltip>
      )}
      <PopUp
        isOpen={isEdit}
        onClose={() => setIsEdit(false)}
        heading="Update Square Ads"
      >
        <AdsUploader
          onClose={() => setIsEdit(false)}
          addType={adType}
          ad={selectedItem}
        />
      </PopUp>

      {confirmationData.id === 1 && (
        <Confirmation
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={handleDelete}
          description="Are you sure you want to delete this ads?"
          title="Delete Ads"
          btnDanger={true}
          btnTitle="Delete"
        />
      )}
      {confirmationData.id === 2 && (
        <Confirmation
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={RenewPlan}
          description={confirmationData.title}
          title="Renew Ads"
          btnTitle="Renew Now"
        />
      )}
      {confirmationData.id === 3 && (
        <Confirmation
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={ExtendExpiry}
          description={confirmationData.title}
          title="Extent Expiry"
          btnTitle="Extent"
        />
      )}
    </>
  );
};

export default AdsList;
