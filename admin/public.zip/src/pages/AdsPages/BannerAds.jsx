import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import AsyncWrapper from "../../utils/AsyncWrapper";
import PopUp from "../../utils/PopUp";
import httpClient from "../../api/httpClient";
import AddButton from "../../components/AddButton";
import AddAdvertisementNews from "../../components/title-ads/AddAdvertisementNews";
import { useFetchAds } from "../../hooks/ads";
import AdsList from "./AdsList";
import { useEffect } from "react";
import AdsUploader from "./AdsUploader";

const BannerAds = () => {
  const [showAdd, setShowAdd] = useState(0);
  const [ads, setAds] = useState([]);
  const [addAds, setAddAds] = useState(false);
  const [addBreakingNews, setAddBreakingNews] = useState(false);
  const scrollRef = useRef(null);
  const { isPending, data, isError, error, refetch } = useFetchAds();

  useEffect(() => {
    if (data?.banner) setAds(Array.isArray(data.banner) ? data.banner : []);
  }, [data]);

  return (
    <div className="mx-auto p-3 bg-surface rounded-md h-full">
      <AddButton addfun={() => setAddAds(true)} />
      <div
        className="space-y-3 h-full overflow-auto p-0.5 md:p-2"
        ref={scrollRef}
      >
        <AsyncWrapper isError={isError} isPending={isPending} error={error}>
          <AdsList
            setShowAdd={setShowAdd}
            ads={ads}
            setAds={setAds}
            refetch={refetch}
            adType={1}
          />
        </AsyncWrapper>
      </div>
      <PopUp
        isOpen={addBreakingNews}
        onClose={() => setAddBreakingNews(false)}
        heading="Add Banner News"
      >
        <AddAdvertisementNews
          setAddBreakingNews={setAddBreakingNews}
          refetch={refetch}
        />
      </PopUp>
      <PopUp
        isOpen={addAds}
        onClose={() => setAddAds(false)}
        heading="Add Banner Ads"
      >
        <AdsUploader onClose={setAddAds} refetch={refetch} addType={1} />
      </PopUp>
    </div>
  );
};

export default BannerAds;
