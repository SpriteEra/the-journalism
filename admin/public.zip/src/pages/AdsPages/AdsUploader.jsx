import React, { useState } from "react";
import { toast } from "react-hot-toast";
import { handleImageError } from "../../utils/imageError.js";
import { useQueryClient } from "@tanstack/react-query";

// import bannerImg from "../../assets/errorimg1.png";
import httpClient from "../../api/httpClient";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useFetchSingleAds } from "../../hooks/ads.js";
import InputFields from "../../utils/InputFields.jsx";
import { Anchor, Mail } from "lucide-react";
function useQuery() {
  return new URLSearchParams(useLocation().search);
}
const AdsUploader = ({
  setShowAdd,
  showAdd,
  onClose,
  refetch,
  addType,
  ad,
}) => {
  let [banner, setBanner] = useState("./errorimg1.png");
  const [email, setEmail] = useState("");
  const [isLink, setIsLink] = useState(false);
  const [link, setLink] = useState("");
  const [image, setImage] = useState(null);
  const query = useQuery();
  const add_id = query.get("add_id");
  const queryClient = useQueryClient();

  const { data, isPending, isError, error } = useFetchSingleAds(add_id);

  // console.log(add_id);
  const handleImage = (e) => {
    if (e.target.files[0]) {
      setImage(e.target.files[0]);
      setBanner(URL.createObjectURL(e.target.files[0]));
    }
  };

  const typeData = {
    1: "rectangle",
    2: "square",
    3: "detail",
  };

  const headingText = {
    1: "Create a Main Ad (1093 X 297)",
    2: "Create a Side Ad (350 X 350)",
    3: "Create a Detail Ad (1093 X 297)",
  };
  const navigate = useNavigate();
  const removeAddId = () => {
    const params = new URLSearchParams(location.search);
    params.delete("add_id");

    navigate(`${location.pathname}?${params.toString()}`, { replace: true });
  };
  const handleSave = () => {
    if (!image && !banner) {
      toast.error("Please choose an image");
      return;
    }
    if (isLink && !link) {
      toast.error("Please enter a link");
      return;
    }
    const formData = new FormData();
    formData.append("add_id", ad?._id);
    formData.append("banner", image);
    formData.append("link", link);
    formData.append("email", email);
    formData.append("type", typeData[addType]);
    if (ad) {
      let loadingToast = toast.loading("Updating...");
      httpClient
        .put(`/ads/update/${ad._id}`, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then(({ data }) => {
          toast.dismiss(loadingToast);
          toast.success("Advertisement updated successfully");
          onClose();
          queryClient.invalidateQueries({
            queryKey: ["ads"], // Will match all with prefix ['event-news', ...]
          });
        })
        .catch((err) => {
          toast.dismiss(loadingToast);
          toast.error("Failed to update advertisement");
          console.log(err);
        });
    } else {
      let loadingToast = toast.loading("Uploading...");
      httpClient
        .post("/ads/add", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then(({ data }) => {
          toast.dismiss(loadingToast);
          toast.success("Advertisement created successfully");
          onClose();
          queryClient.invalidateQueries({
            queryKey: ["ads"],
          });
        })
        .catch((err) => {
          toast.dismiss(loadingToast);
          toast.error("Failed to create advertisement");
          console.log(err);
        });
    }
  };
  useEffect(() => {
    if (ad) {
      setBanner(ad?.banner?.url);
      setLink(ad?.link);
      setEmail(ad?.email);
    }
  }, [ad]);
  return (
    <div className="w-full border-line-strong rounded-lg ">
      <h2 className="text-xl font-medium mb-4 dark:font-medium">
        {headingText[addType]}
      </h2>

      <div
        className={`relative ${
          addType === 2 ? "h-[250px] sm:h-[300px]" : " h-[297px]"
        } ${
          addType === 2 ? "w-full sm:w-[300px]" : " w-full"
        } hover:opacity-80 bg-surface border-2 border-blue rounded-md`}
      >
        <label htmlFor="uploadBanner">
          <img
            src={banner}
            alt="Default Banner"
            className="z-20 rounded-md w-full h-full object-fill"
            onError={handleImageError}
          />
          <input
            type="file"
            id="uploadBanner"
            accept=".png, .jpg, .jpeg, .webp"
            hidden
            onChange={handleImage}
          />
        </label>
      </div>

      <div className="grid grid-cols-1 items-center mt-4">
        <InputFields
          LabelTitle="Email"
          inputVal={email}
          handleInputValue={(e) => setEmail(e.target.value)}
          name="email"
          type="email"
          placeholder={"example@gmail.com..."}
          icon={Mail}
        />
        <InputFields
          LabelTitle="Link"
          inputVal={link}
          handleInputValue={(e) => setLink(e.target.value)}
          name="link"
          placeholder={"https://somedomain.com..."}
          icon={Anchor}
        />
      </div>
      <div className="flex justify-end gap-2">
        <button className="btn-red" onClick={handleSave}>
          {ad ? "Update" : "Create"}
        </button>
        <button className="btn-red-outline" onClick={() => setShowAdd(0)}>
          Cancel
        </button>
      </div>
    </div>
  );
};

export default AdsUploader;
