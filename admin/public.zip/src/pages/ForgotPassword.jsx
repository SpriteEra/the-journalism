import { useState } from "react";
import { Lock, Mail } from "lucide-react";
import InputFields from "../utils/InputFields";
import ToggleTheme from "../utils/ToggleTheme";
import { Link } from "react-router-dom";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="flex h-screen w-full bg-surface-2">
      <ToggleTheme />
      <div className="w-full  flex justify-center items-center ">
        <div className="w-full max-w-md px-8 py-12 shadow-2xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-fg">
              Forgot Password
            </h2>
            <p className="text-fg-subtle mt-2">
              We're so excited to help you!
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <InputFields
              name="email"
              required={true}
              inputVal={email}
              placeholder={"Enter your email"}
              type="email"
              LabelTitle="Email"
              icon={Mail}
              handleInputValue={(e) => setEmail(e.target.value)}
            />

            <div className="flex justify-end">
              <Link to={"/login"} className="text-info">
                Login?
              </Link>
            </div>

            <div>
              <button type="submit" className="btn-blue w-full">
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
