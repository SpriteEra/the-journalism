import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useFetchNews, useFetchScheduleNews } from "../hooks/news";
import { BookOpen, RotateCcw, Search, TextSearch } from "lucide-react";
import { formatDate } from "../utils/utils";
import Loader from "../components/Loader";
import SocialShare from "../components/SocialShare";
import Confirmation from "../utils/Confirmation";
import NewsFilter from "../components/NewsFilter";
import Pagination from "../utils/Pagination";
import { useSearchParams } from "react-router-dom";
import { useRef } from "react";
import AsyncWrapper from "../utils/AsyncWrapper";
import toast from "react-hot-toast";
import httpClient from "../api/httpClient";
import { handleImageError } from "../utils/imageError";
const ScheduledNews = () => {
  const navigate = useNavigate();
  const [selectedOptions, setSelectedOptions] = useState({
    news_section_type: [],
    district: [],
    state: [],
    location: "",
    createdAt: "",
    search: "",
  });
  const [appliedFilters, setAppliedFilters] = useState(selectedOptions);

  const [searchParams, setSearchParams] = useSearchParams();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const itemsPerPage = 10;
  const [search, setSearch] = useState("");
  const [isDeleteNews, setIsDeleteNews] = useState(false);
  const [news, setNews] = useState(null);
  const [id, setId] = useState(null);
  const pageFromUrl = parseInt(searchParams.get("page") || "1", 10);
  const [page, setPage] = useState(pageFromUrl);
  const scrollRef = useRef(null);

  const openFilter = () => {
    setIsFilterOpen(true);
    // document.body.style.overflow = "hidden"; // Disable scroll
  };

  const closeFilter = () => {
    setIsFilterOpen(false);
    // document.body.style.overflow = "auto"; // Enable scroll
  };

  const handleSubmitSearch = (e) => {
    e.preventDefault();
    // if (e.key === "Enter") {
    //   setSelectedOptions((prevOptions) => ({
    //     ...prevOptions,
    //     search: e.target.value,
    //   }));
    // }
    setAppliedFilters({
      ...selectedOptions,
      search: search,
    });
  };
  const handleSubmit = () => {
    setAppliedFilters(selectedOptions);
  };

  const { data, isPending, isError, error, refetch } = useFetchScheduleNews({
    page,
    limit: itemsPerPage,
  });

  const handleDelete = async () => {
    try {
      if (!id) return;
      let loadingToast = toast.loading("Deleting...");
      const { data } = await httpClient.delete(`/delete-scheduled-news/${id}`);
      setIsDeleteNews(false);
      toast.dismiss(loadingToast);
      toast.success("News Deleted Successfully");
      refetch();
    } catch (err) {
      console.log(err);
      toast.dismiss(loadingToast);
      setIsDeleteNews(false);
      toast.error("Failed to delete news");
    }
  };

  const handlePublish = async () => {
    let loadingToast = toast.loading("Publishing...");
    await httpClient
      .put(`publish-scheduled-news`, { news_id: id })
      .then(async ({ data }) => {
        toast.dismiss(loadingToast);
        toast.success("News published successfully");
        setIsModalOpen(false);
        refetch();
        // fetchNews({ page: news?.page });
      })
      .catch((err) => {
        console.log(err);
        toast.dismiss(loadingToast);
        toast.error("Failed to publish news");
        setConfirmPublisOpen(false);
      });
  };

  const handleResetFilter = () => {
    setAppliedFilters({
      news_section_type: [],
      district: [],
      state: [],
      location: "",
      createdAt: "",
      search: "",
    });
    // fetchNews({ page: 1, findCount: true });
  };

  useEffect(() => {
    setSearchParams({ page });
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: 0, behavior: "smooth" }); // 👈 scroll div to top
    }
  }, [page]);

  return (
    <div className="mx-auto p-1 sm:p-2 bg-surface rounded-md">
      <div className="flex justify-between max-md:flex-col items-center gap-4 mb-2">
        <div className="flex gap-x-1 sm:gap-x-3 max-sm:justify-between max-sm:w-full overflow-x-auto justify-end w-full">
          <button className="flex gap-x-1 sm:gap-x-2 items-center text-base sm:text-lg shadow p-1 rounded-sm px-1 sm:px-2 text-primary whitespace-nowrap max-sm:text-sm">
            <BookOpen size={20} />
            Total News : {data?.total}
          </button>
        </div>
      </div>
      <div
        className="space-y-3 h-[calc(100vh-165px)] sm:h-[calc(100vh-190px)] md:h-[calc(100vh-220px)] overflow-auto p-0.5 md:p-2"
        ref={scrollRef}
      >
        <AsyncWrapper isError={isError} isPending={isPending} error={error}>
          {data?.news?.length ? (
            data?.news?.map((item, index) => (
              <div
                key={index}
                className="grid sm:grid-cols-7 lg:grid-cols-6 gap-2 items-center p-1 max-sm:pb-2 sm:p-2 rounded shadow-card dark:border-b"
                // style={{boxShadow: `rgba(100, 100, 111, 0.2) 0px 7px 29px 0px`}}
              >
                <div className="sm:col-span-2 lg:col-span-1">
                  <img
                    src={`${item?.banner}?q=75&w=300`}
                    alt="news"
                    className="w-full h-36 sm:h-24 object-cover"
                    onError={handleImageError}
                  />
                </div>
                <div className="sm:col-span-5 lg:col-span-5">
                  <div className="flex-1">
                    <h3 className="sm:text-lg line-clamp-2 sm:line-clamp-1 hindi-font font-semibold text-fg dark:font-medium">
                      {item.title}
                    </h3>
                    <div className="flex max-sm:flex-col justify-start gap-y-1 gap-x-3 lg:gap-x-8">
                      <p className="text-sm sm:text-[16px] text-fg-subtle">
                        <span className="text-fg">
                          Created On:
                        </span>{" "}
                        {formatDate(item.createdAt)}
                      </p>
                      <p className="text-sm sm:text-[16px] text-fg-subtle">
                        <span className="font-light text-fg">
                          Scheduled for:
                        </span>{" "}
                        {item.post_time?.date}, {item.post_time?.time}
                      </p>
                      <p className="text-sm sm:text-[16px] text-fg-subtle">
                        <span className="text-fg">
                          Reporter
                        </span>
                        <Link className="text-primary border-b border-blue ml-2 font-light">
                          @{item?.author?.username}
                        </Link>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 sm:gap-4 mt-2 sm:mt-1">
                    <button
                      className="bg-accent text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() => {
                        setIsDeleteNews(true);
                        setId(item?.news_id);
                      }}
                    >
                      Delete
                    </button>
                    <button
                      className="bg-primary  text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() =>
                        navigate(
                          `/dashboard/news/edit-news/${item?.news_id}?type=schedule_news&mode=edit`
                        )
                      }
                    >
                      Edit
                    </button>

                    <button
                      className="bg-primary text-paper px-3 py-0.5 rounded text-base cursor-pointer"
                      onClick={() => {
                        setIsModalOpen(true);
                        setId(item?.news_id);
                      }}
                    >
                      Publish
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-1 items-center justify-center h-full">
              <h5 className="text-3xl text-fg-muted hindi-font">
                कोई खबर उपलब्ध नहीं है
              </h5>
            </div>
          )}
        </AsyncWrapper>
      </div>
      <div className="flex justify-between mt-4">
        <Pagination
          totalItems={data?.total}
          itemsPerPage={itemsPerPage}
          defaultCurrent={1}
          current={page}
          onChange={(val) => setPage(val)}
          isLoading={isPending}
        />
      </div>

      <Confirmation
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handlePublish}
        btnTitle="Publish"
        title="Are you sure?"
        description="Are you sure you want to publish this news."
      />
      <Confirmation
        isOpen={isDeleteNews}
        onClose={() => setIsDeleteNews(false)}
        onConfirm={handleDelete}
        btnTitle="Delete"
        title="Are you sure?"
        btnDanger={true}
        description="Are you sure you want to delete this news"
      />
      <NewsFilter
        handleSubmit={handleSubmit}
        setSelectedOptions={setSelectedOptions}
        selectedOptions={selectedOptions}
        isOpen={isFilterOpen}
        onClose={closeFilter}
      />
    </div>
  );
};

export default ScheduledNews;
