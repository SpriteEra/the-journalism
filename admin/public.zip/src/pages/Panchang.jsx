import { useRef, useState } from "react";
import toast from "react-hot-toast";
import { Search, Image as ImageIcon } from "lucide-react";
import AsyncWrapper from "../utils/AsyncWrapper";
import { useFetchPanchang } from "../hooks/panchang";
import { formatDate } from "../utils/utils";
import Pagination from "../utils/Pagination";
import PopUp from "../utils/PopUp";
import Confirmation from "../utils/Confirmation";

import httpClient from "../api/httpClient";
import AddButton from "../components/AddButton";
import AddPanchang from "../components/panchang/AddPanchang";
import { Link } from "react-router-dom";

const Panchang = () => {
  const [search, setSearch] = useState("");
  const [finalSearch, setFinalSearch] = useState("");
  const [page, setPage] = useState(1);
  const [id, setId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const itemsPerPage = 12;
  const [addPanchang, setAddPanchang] = useState(false);
  const [editPanchang, setEditPanchang] = useState(false);
  const [selectedPanchang, setSelectedPanchang] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);

  const scrollRef = useRef(null);

  const handleSubmitSearch = (e) => {
    e.preventDefault();
    setFinalSearch(search);
    refetch();
  };

  const { isPending, data, isError, error, refetch } = useFetchPanchang({
    page,
    search: finalSearch,
    limit: itemsPerPage,
  });

  const handleDelete = async (e) => {
    if (isDeleting) return;
    setIsDeleting(true);
    if (!id) return toast.error("Try again.");
    let loadingToast = toast.loading("Deleting Panchang...");
    try {
      const { data } = await httpClient.delete(`delete-panchang/${id}`);
      setIsModalOpen(false);
      toast.dismiss(loadingToast);
      toast.success("Panchang Deleted Successfully");
      refetch();
      setIsDeleting(false);
    } catch (err) {
      toast.dismiss(loadingToast);
      toast.error("Failed to delete panchang");
      console.log(err);
      setIsDeleting(false);
      setIsModalOpen(false);
    }
  };

  const handleImagePreview = (imageUrl) => {
    setImagePreview(imageUrl);
  };

  const validateImageFile = (file) => {
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif"];
    const maxSize = 5 * 1024 * 1024; // 5MB

    if (!allowedTypes.includes(file.type)) {
      toast.error("Please upload only JPG, JPEG, PNG, or GIF images");
      return false;
    }

    if (file.size > maxSize) {
      toast.error("Image size should be less than 5MB");
      return false;
    }

    return true;
  };

  return (
    <div className="mx-auto p-1 sm:p-3 bg-surface rounded-md">
      <AddButton addfun={() => setAddPanchang(true)} />
      <div className="flex justify-between max-md:flex-col items-center gap-4 mb-2">
        <form
          onSubmit={handleSubmitSearch}
          className="border-2 rounded-sm w-full sm:w-60 flex justify-between items-center"
        >
          <input
            type="text"
            placeholder="Search Panchang"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
            }}
            className="border-none outline-none max-sm:p-1 p-1 rounded"
          />
          <Search size={25} className="max-sm:pr-1 p-1" />
        </form>
      </div>

      <div
        className="h-[calc(100vh-165px)] sm:h-[calc(100vh-190px)] md:h-[calc(100vh-220px)] overflow-auto p-0.5 md:p-2"
        ref={scrollRef}
      >
        <AsyncWrapper isError={isError} isPending={isPending} error={error}>
          {data?.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {data?.map((item, index) => (
                <div
                  key={index}
                  className="bg-surface rounded-lg shadow-card dark:border overflow-hidden max-w-80 mx-auto"
                >
                  {/* Image */}
                  <div className="relative aspect-square">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt="Panchang"
                        className="w-full h-full object-cover cursor-pointer hover:opacity-90 transition-opacity"
                        onClick={() => handleImagePreview(item.image)}
                      />
                    ) : (
                      <div className="w-full h-full bg-surface-3 flex items-center justify-center">
                        <ImageIcon size={48} className="text-fg-faint" />
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-3">
                    <div className="text-sm text-fg-subtle">
                      {formatDate(item.createdAt)}
                    </div>
                    <div className="text-sm sm:text-lg text-gray mb-2">
                      <span className="text-fg">
                        Reporter
                      </span>
                      <span className="text-primary border-b border-blue ml-2 font-light">
                        @{item?.author?.username}
                      </span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 mt-1">
                      <button
                        className="flex-1 bg-accent text-paper px-3 py-1 rounded text-sm cursor-pointer hover:opacity-90 transition-opacity"
                        onClick={() => {
                          setIsModalOpen(true);
                          setId(item?._id);
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-1 items-center justify-center h-full">
              <div className="text-center">
                <ImageIcon size={48} className="mx-auto text-fg-faint mb-4" />
                <h5 className="text-3xl text-fg-muted hindi-font">
                  कोई पंचांग उपलब्ध नहीं है
                </h5>
                <p className="text-fg-subtle mt-2">No Panchang available</p>
              </div>
            </div>
          )}
        </AsyncWrapper>
      </div>

      {/* Add Panchang Modal */}
      <PopUp
        isOpen={addPanchang}
        onClose={() => setAddPanchang(false)}
        heading="Add Panchang Image"
      >
        <AddPanchang
          setAddPanchang={setAddPanchang}
          refetch={refetch}
          validateImageFile={validateImageFile}
        />
      </PopUp>

      {/* Image Preview Modal */}
      <PopUp
        isOpen={imagePreview}
        onClose={() => setImagePreview(null)}
        heading="Panchang Image"
      >
        <div className="max-w-4xl max-h-[90vh] overflow-auto">
          <img
            src={imagePreview}
            alt="Panchang Preview"
            className="w-full h-auto rounded"
          />
        </div>
      </PopUp>

      {/* Delete Confirmation Modal */}
      <Confirmation
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handleDelete}
        description="Are you sure you want to delete this panchang image? This action cannot be undone."
        title="Delete Panchang"
        btnDanger={true}
        btnTitle="Delete"
        isLoading={isDeleting}
      />
    </div>
  );
};

export default Panchang;
