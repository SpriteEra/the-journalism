import { Link } from "react-router-dom";
import { Eye, FileText, Hourglass, PlaySquare, Plus, Users } from "lucide-react";
import { useMemo } from "react";
import usePermission from "../../hooks/usePermission";
import { useAnalyticsDashboard } from "../../hooks/admin";
import { fmtDate } from "../../lib/api";
import { rangeFromDays } from "../../components/analytics/RangePicker";
import { TrendChart } from "../../components/charts/Charts";
import { buttonStyles } from "../../components/ui/Button";
import { Badge, Card, CardHeader, EmptyState, ErrorState, PageHeader, Skeleton, StatCard } from "../../components/ui";

const greeting = () => { const h = new Date().getHours(); return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"; };

function QuickActions({ can }) {
  const actions = [
    can("news.create") && { to: "/dashboard/news/create", label: "Write news", icon: Plus },
    can("news.approve") && { to: "/dashboard/review-news", label: "Review queue", icon: Hourglass },
    can(["video.create"]) && { to: "/dashboard/short-videos", label: "Add video / short", icon: PlaySquare },
  ].filter(Boolean);
  return actions.length ? <div className="flex flex-wrap gap-2">{actions.map((a) => <Link key={a.to} to={a.to} className={buttonStyles({ variant: a.icon === Plus ? "primary" : "outline" })}><a.icon className="size-4" />{a.label}</Link>)}</div> : null;
}

export default function Overview() {
  const { user, can } = usePermission();
  const range = useMemo(() => rangeFromDays(14), []);
  const canSee = can("analytics.view");
  const { data, isLoading, error, refetch } = useAnalyticsDashboard(range, canSee);
  const d = data?.data; const o = d?.overview;

  return (
    <>
      <PageHeader title={`${greeting()}, ${user?.fullName || user?.username}`} description="Here's what's happening in the newsroom over the last 14 days." actions={<QuickActions can={can} />} />

      {!canSee ? (
        <Card><EmptyState title="Welcome to the admin panel" description="Use the menu to open the sections you have access to." action={<QuickActions can={can} />} /></Card>
      ) : error ? <ErrorState error={error} onRetry={refetch} /> : (
        <div className="space-y-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Stories published" value={o?.news.published ?? 0} icon={FileText} change={o?.news.change.publishedPercent} hint="vs previous 14 days" loading={isLoading} />
            <StatCard label="Reads on those stories" value={o?.news.views ?? 0} icon={Eye} tone="accent" change={o?.news.change.viewsPercent} loading={isLoading} />
            <StatCard label="Waiting for review" value={o?.workflow.pendingApproval ?? 0} icon={Hourglass} tone="warning" hint={o?.workflow.oldestPendingSince ? `oldest ${fmtDate(o.workflow.oldestPendingSince)}` : "all clear"} loading={isLoading} />
            <StatCard label="Active reporters" value={o?.news.activeReporters ?? 0} icon={Users} tone="success" hint={`${o?.people.total ?? 0} team members`} loading={isLoading} />
          </div>

          <div className="grid gap-5 xl:grid-cols-3">
            <Card padded={false} className="xl:col-span-2">
              <CardHeader title="Publishing & reads" description="Stories published per day and their reads" actions={<Link to="/dashboard/analytics" className="text-sm font-medium text-primary hover:underline">Full analytics →</Link>} />
              <div className="p-4">{isLoading ? <Skeleton className="h-72 w-full" /> : <TrendChart data={d.timeseries.series} series={[{ key: "published", name: "Stories" }, { key: "views", name: "Reads" }]} />}</div>
            </Card>
            <Card padded={false}>
              <CardHeader title="Top stories" description="Most read in this period" />
              <ol className="divide-y divide-line">
                {isLoading ? [0, 1, 2, 3, 4].map((i) => <li key={i} className="p-4"><Skeleton className="h-4 w-full" /></li>) : d.topArticles.length ? d.topArticles.slice(0, 6).map((a, i) => (
                  <li key={a.news_id}>
                    <Link to={`/dashboard/news/${a.news_id}`} className="flex items-start gap-3 px-5 py-3 hover:bg-surface-2/60">
                      <span className="grid size-6 shrink-0 place-items-center rounded-md bg-surface-3 text-xs font-semibold text-fg-muted">{i + 1}</span>
                      <span className="min-w-0 flex-1"><span className="line-clamp-2 text-sm font-medium text-fg">{a.title}</span><span className="text-xs text-fg-subtle">{a.category?.[0]?.name} · {a.author?.username}</span></span>
                      <Badge tone="primary" size="sm"><Eye className="size-3" />{(a.activity?.total_reads || 0).toLocaleString("en-IN")}</Badge>
                    </Link>
                  </li>
                )) : <li><EmptyState title="No stories yet" /></li>}
              </ol>
            </Card>
          </div>

          {d?.dataQuality && (d.dataQuality.publishedWithoutCategory > 0 || d.dataQuality.publishedWithoutTags > 0) && (
            <Card className="border-warning/40 bg-warning-soft/40">
              <p className="text-sm text-fg-muted"><b className="text-fg">Heads-up:</b> {d.dataQuality.publishedWithoutCategory} published stories have no category and {d.dataQuality.publishedWithoutTags} have no tags – they won't appear in category / tag pages.</p>
            </Card>
          )}
        </div>
      )}
    </>
  );
}
