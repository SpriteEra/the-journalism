import { useEffect, useState } from "react";
import { Lock, Mail, Moon, ShieldCheck, Sun } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import toast from "react-hot-toast";
import { getUser, getUserFail, getUserSuccess } from "../redux/slices/user.slice";
import httpClient from "../api/httpClient";
import { useTheme } from "../utils/Theme";
import { errMsg } from "../lib/api";
import { Button, Field, IconButton, Input } from "../components/ui";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { search } = useLocation();
  const redirect = new URLSearchParams(search).get("redirect");
  const { user } = useSelector((s) => s.user);
  const { resolved, toggleTheme } = useTheme();

  useEffect(() => { if (user) navigate(redirect && redirect !== "/login" ? redirect : "/dashboard", { replace: true }); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    dispatch(getUser());
    try {
      const { data } = await httpClient.post("sign-in", { email, password });
      dispatch(getUserSuccess(data));
      // older backends do not send permissions with the login response – /me always does
      if (!data?.user?.permissions) {
        try { const me = await httpClient.get("/me"); dispatch(getUserSuccess({ user: me.data.user })); } catch { /* keep the login payload */ }
      }
      toast.success("Welcome back!");
      navigate(redirect && redirect !== "/login" ? redirect : "/dashboard");
    } catch (error) {
      dispatch(getUserFail());
      toast.error(errMsg(error, "Could not sign in"));
    } finally { setLoading(false); }
  };

  return (
    <div className="grid min-h-dvh bg-canvas lg:grid-cols-[1.1fr_1fr]">
      {/* brand panel – desktop only */}
      <aside className="relative hidden overflow-hidden bg-sidebar p-12 text-sidebar-fg lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 size-96 rounded-full bg-sidebar-active/20 blur-3xl" aria-hidden />
        <div className="absolute -bottom-32 -left-16 size-96 rounded-full bg-primary/40 blur-3xl" aria-hidden />
        <img src="/janpad-news-times-logo.png" alt="Janpad News Times" className="relative h-14 w-fit rounded-lg bg-paper/95 px-3 py-2" />
        <div className="relative max-w-md">
          <ShieldCheck className="mb-5 size-10 text-sidebar-active" />
          <h2 className="text-3xl font-semibold leading-tight">Run the newsroom from one place.</h2>
          <p className="mt-3 text-sidebar-muted">Write, review and publish stories, manage shorts and videos, and see how your team performs – with permissions for every role.</p>
        </div>
        <p className="relative text-sm text-sidebar-muted">© {new Date().getFullYear()} Janpad News Times</p>
      </aside>

      <main className="relative flex items-center justify-center p-5 sm:p-10">
        <IconButton label="Toggle theme" onClick={toggleTheme} className="absolute right-4 top-4">{resolved === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}</IconButton>
        <div className="w-full max-w-sm">
          <img src="/janpad-news-times-logo.png" alt="Janpad News Times" className="mb-8 h-12 w-fit lg:hidden" />
          <h1 className="text-2xl font-semibold tracking-tight text-fg">Sign in</h1>
          <p className="mt-1 text-sm text-fg-subtle">Use your newsroom account to continue.</p>
          <form onSubmit={submit} className="mt-8 space-y-5">
            <Field label="Email or username" required><Input icon={Mail} autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@janpadnewstimes.com" required autoFocus /></Field>
            <Field label="Password" required labelExtra={<Link to="/forgot-password" className="text-xs font-medium text-primary hover:underline">Forgot password?</Link>}>
              <Input icon={Lock} type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your password" required />
            </Field>
            <Button type="submit" size="lg" block loading={loading}>Sign in</Button>
          </form>
        </div>
      </main>
    </div>
  );
}
