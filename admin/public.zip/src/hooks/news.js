import httpClient from '../api/httpClient'
import { useQuery } from "@tanstack/react-query";
const fetchNews = async ({ queryKey }) => {
  const [_key, { page, limit, draft, need_approval, filters }] = queryKey;

  const { category, subCategory, district, state, location, createdAt, search, tag } = filters;

  const params = {
    page,
    limit,
    draft,
    category,
    subCategory,
    tag,
    district,
    state,
    location,
    createdAt,
    search,
    need_approval
  };

  const { data } = await httpClient.get('/get-news', { params });
  return data;
};

export const useFetchNews = ({ page, need_approval = false, limit, draft = false, filters }) => {
  return useQuery({
    queryKey: ['news', { page, limit, draft, filters, need_approval }],
    queryFn: fetchNews,
    placeholderData: (previous) => previous,
    staleTime: 1000 * 60 * 2,
  });
};
const fetchScheduleNews = async ({ queryKey }) => {
  const [_key, { page, limit, }] = queryKey;
  const params = {
    page,
    limit,
  };

  const { data } = await httpClient.get('/scheduled-news', { params });
  return data;
};

export const useFetchScheduleNews = ({ page, limit }) => {
  return useQuery({
    queryKey: ['schedule-news', { page, limit, }],
    queryFn: fetchScheduleNews,
    placeholderData: (previous) => previous,
    staleTime: 1000 * 60 * 2,
  });
};


const fetchBreakingNews = async ({ queryKey }) => {
  const [_key, { page, limit, search }] = queryKey;
  const params = {
    page,
    limit,
    search,
  };

  const { data } = await httpClient.get('/get-breaking-news', { params });
  return data;
};

export const useFetchBreakingNews = ({ page, limit, search }) => {
  return useQuery({
    queryKey: ['breaking-news', { page, limit, search }],
    queryFn: fetchBreakingNews,
    placeholderData: (previous) => previous,
    staleTime: 1000 * 60 * 2,
  });
};



const fetchEventNews = async ({ queryKey }) => {
  const [_key, { page, limit, filters }] = queryKey;

  const { type, createdAt, search } = filters;

  const params = {
    page,
    limit,
    createdAt,
    type,
    search,
  };

  const { data } = await httpClient.get('/get-event-news', { params });
  return data;
};

export const useFetchEventNews = ({ page, limit, draft = false, filters }) => {
  return useQuery({
    queryKey: ['event-news', { page, limit, draft, filters }],
    queryFn: fetchEventNews,
    placeholderData: (previous) => previous,
    staleTime: 1000 * 60 * 2,
  });
};


const fetchSingleEventNews = async (news_id) => {
  const { data } = await httpClient.get(`/get-single-event-news/${news_id}`);
  return data;
};

export const useFetchSingleEventNews = (news_id) => {
  return useQuery({
    queryKey: ['single-event-news', news_id],
    queryFn: () => fetchSingleEventNews(news_id),
    keepPreviousData: false,
    staleTime: 0,
  });
};


const fetchGalleryNews = async ({ queryKey }) => {
  const [_key, { page, limit, draft, filters }] = queryKey;

  const { news_section_type, district, state, location, createdAt, search } = filters;

  const params = {
    page,
    limit,
    draft,
    news_section_type,
    district,
    state,
    location,
    createdAt,
    search,
  };

  const { data } = await httpClient.get('/gallery-news', { params });
  return data;
};

export const useFetchGalleryNews = ({ page, limit, draft = false, filters }) => {
  return useQuery({
    queryKey: ['gallery-news', { page, limit, draft, filters }],
    queryFn: fetchGalleryNews,
    placeholderData: (previous) => previous,
    staleTime: 1000 * 60 * 2,
  });
};
