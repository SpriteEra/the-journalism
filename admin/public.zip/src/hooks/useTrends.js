import httpClient from '../api/httpClient';
import { useQuery } from "@tanstack/react-query";

// ✅ Fetch Top 100 Trends
const fetchTopTrends = async () => {
    const { data } = await httpClient.get('/spriteera-service/top-100-trends');
    return data;
};

// export const useFetchTopTrends = () => {
//     return useQuery({
//         queryKey: ['top-trends'],
//         queryFn: fetchTopTrends,
//         // staleTime: 1000 * 60 * 10, // ✅ 10 minutes
//         // keepPreviousData: true,
//     });
// };


// ✅ Fetch Related Tags (AI + Trending mix)
const fetchRelatedTags = async ({ title, description }) => {
    const { data } = await httpClient.post('/spriteera-service/generate-tags', {
        title,
        content: description,
    });
    return data;
};

export const useFetchRelatedTags = ({ title, description, enabled }) => {
    return useQuery({
        queryKey: ['related-tags', title, description],
        queryFn: () => fetchRelatedTags({ title, description }),
        enabled, // only call when needed
        staleTime: 1000 * 60 * 10, // ✅ 10 min
    });
};


const STALE_6H = 1000 * 60 * 60 * 6;


const fetchRssFeed = async () => {
    const { data } = await httpClient.get("/spriteera-service/rss");
    return data;
};

export const useFetchTopTrends = () =>
    useQuery({
        queryKey: ["top-trends"],
        queryFn: fetchTopTrends,
        staleTime: STALE_6H,
        refetchInterval: STALE_6H,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
    });

export const useFetchRss = () =>
    useQuery({
        queryKey: ["rss-feed"],
        queryFn: fetchRssFeed,
        // staleTime: STALE_6H,
        // refetchInterval: STALE_6H,
        // refetchOnWindowFocus: false,
        // refetchOnMount: false,
    });

//