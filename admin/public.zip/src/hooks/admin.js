import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import httpClient from "../api/httpClient";
import { cleanParams, errMsg } from "../lib/api";

/**
 * Data hooks for the admin screens (roles, tags, taxonomy, shorts, analytics, users).
 * Every list uses react-query keys: [name, params] so a mutation can `invalidate: ["tags"]`.
 */
const get = (url, params) => httpClient.get(url, { params: cleanParams(params) }).then((r) => r.data);

export const useApiMutation = (fn, { invalidate = [], success, onSuccess } = {}) => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: (data, vars) => {
      invalidate.forEach((k) => qc.invalidateQueries({ queryKey: Array.isArray(k) ? k : [k] }));
      const msg = typeof success === "function" ? success(data, vars) : success ?? data?.message;
      if (msg) toast.success(msg);
      onSuccess?.(data, vars);
    },
    onError: (e) => toast.error(errMsg(e)),
  });
};

// roles & permissions
export const usePermissionCatalog = () => useQuery({ queryKey: ["permission-catalog"], queryFn: () => get("/permissions"), staleTime: 5 * 60_000 });
export const useRoles = () => useQuery({ queryKey: ["roles"], queryFn: () => get("/roles"), select: (d) => d.roles });

// users
export const useUsers = (params) => useQuery({ queryKey: ["users", params], queryFn: () => get("/reporters", params), placeholderData: (p) => p });
export const useUserDetail = (id) => useQuery({ queryKey: ["user", id], queryFn: () => get(`/reporters/${id}`), enabled: Boolean(id) });

// tags
export const useTags = (params) => useQuery({ queryKey: ["tags", params], queryFn: () => get("/tags", params), placeholderData: (p) => p });
export const useTagSuggest = (q) => useQuery({ queryKey: ["tag-suggest", q], queryFn: () => get("/tags/suggest", { q, limit: 8 }), select: (d) => d.tags, staleTime: 20_000, placeholderData: (p) => p });

// taxonomy
export const useCategories = () => useQuery({ queryKey: ["categories"], queryFn: () => get("/categories"), select: (d) => d.categories, staleTime: 60_000 });
export const useStates = () => useQuery({ queryKey: ["states"], queryFn: () => get("/states"), select: (d) => d.states, staleTime: 60_000 });
export const useDistricts = (state) => useQuery({ queryKey: ["districts", state || "all"], queryFn: () => get("/districts", { state }), select: (d) => d.districts, staleTime: 60_000 });

// short videos
export const useShortVideos = (params) => useQuery({ queryKey: ["short-videos", params], queryFn: () => get("/short-videos", params), placeholderData: (p) => p });
export const useSyncStatus = (enabled) => useQuery({ queryKey: ["short-videos-sync"], queryFn: () => get("/short-videos/sync-status"), enabled, select: (d) => d.status });

// analytics (cached on the server: X-Cache HIT/STALE/MISS)
export const useAnalyticsDashboard = (range, enabled = true) =>
  useQuery({ queryKey: ["analytics-dashboard", range], queryFn: () => get("/analytics/dashboard", range), enabled, staleTime: 60_000, placeholderData: (p) => p });
export const useReporterPerformance = (id, range, enabled = true) =>
  useQuery({ queryKey: ["reporter-performance", id, range], queryFn: () => get(`/reporters/${id}/performance`, range), enabled, select: (d) => d.report, staleTime: 60_000 });
