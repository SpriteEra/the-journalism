import imageCompression from "browser-image-compression";
import TimeAgo from "javascript-time-ago";
import en from "javascript-time-ago/locale/en.json";

export const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
        case "success":
            return "text-success";
        case "pending":
            return "text-warning";
        case "failed":
            return "text-danger";
        default:
            return "text-fg-subtle";
    }
};

export const truncate = (text, maxLength) => {
    if (!text || text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
};

export const formatDate = (timestamp) => {
    const date = new Date(timestamp);

    // Get parts of the date
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const hours12 = hours % 12 || 12; // Convert to 12-hour format
    const minutesPadded = minutes.toString().padStart(2, '0'); // Add leading zero if needed

    const month = date.toLocaleString('default', { month: 'short' }); // Full month name
    const day = date.getDate();
    const year = date.getFullYear();

    // Format the date string
    return `${hours12}:${minutesPadded} ${ampm}, ${month} ${day}, ${year}`;
}


export const compressImage = async (imageFile, options = {}) => {
    if (!imageFile) throw new Error("No image file provided.");

    const defaultOptions = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true,
    };

    const finalOptions = { ...defaultOptions, ...options };
    const fileSizeMB = imageFile.size / (1024 * 1024);

    if (fileSizeMB > finalOptions.maxSizeMB) {
        return await imageCompression(imageFile, finalOptions);
    }

    return imageFile; // Return original if below size limit
};


TimeAgo.addDefaultLocale(en);

// Create a formatter
const timeAgo = new TimeAgo("en-US");

export const getRelativeTime = (dateString) => {
    return timeAgo.format(new Date(dateString));
};

export const returnChar = (type) => {
    if (!type) {
        return 'O';
    }

    return type.split('')[0].toUpperCase();
}

export const getYearOptions = () => {
    const currentYear = new Date().getFullYear();
    const years = [];

    for (let i = 0; i < 5; i++) {
        years.push((currentYear - i).toString());
    }

    return ["Select Year", ...years];
};
