import Modal from "../components/ui/Modal";

/** Legacy API over <Modal>. */
const PopUp = ({ isOpen, onClose, children, heading = "PopUp", classes = "" }) => (
  <Modal open={isOpen} onClose={onClose} title={heading} size="lg" className={classes}>{children}</Modal>
);

export default PopUp;
