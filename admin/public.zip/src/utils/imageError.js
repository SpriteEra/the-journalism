export const handleImageError = (e) => {
    e.target.src = "/no-img.png";
};