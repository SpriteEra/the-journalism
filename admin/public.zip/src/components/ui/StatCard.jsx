import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { cn } from "../../lib/cn";
import { Skeleton } from "./Feedback";

const TONES = {
  primary: "bg-primary-soft text-primary", accent: "bg-accent-soft text-accent", success: "bg-success-soft text-success",
  warning: "bg-warning-soft text-warning", info: "bg-info-soft text-info", danger: "bg-danger-soft text-danger",
};

/** KPI tile. change = percent vs previous period (number, optional). */
export default function StatCard({ label, value, icon: Icon, tone = "primary", change, hint, loading, className }) {
  const up = change > 0; const flat = !change;
  return (
    <div className={cn("surface-card flex items-start justify-between gap-3 p-4 sm:p-5", className)}>
      <div className="min-w-0">
        <p className="truncate text-sm text-fg-subtle">{label}</p>
        {loading ? <Skeleton className="mt-2 h-8 w-24" /> : <p className="mt-1 text-2xl font-semibold tracking-tight text-fg sm:text-3xl">{typeof value === "number" ? value.toLocaleString("en-IN") : value}</p>}
        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs">
          {change !== undefined && !loading && (
            <span className={cn("inline-flex items-center gap-0.5 font-medium", flat ? "text-fg-subtle" : up ? "text-success" : "text-danger")}>
              {!flat && (up ? <ArrowUpRight className="size-3.5" /> : <ArrowDownRight className="size-3.5" />)}
              {Math.abs(change)}%
            </span>
          )}
          {hint && <span className="text-fg-subtle">{hint}</span>}
        </div>
      </div>
      {Icon && <span className={cn("grid size-11 shrink-0 place-items-center rounded-xl", TONES[tone])}><Icon className="size-5" /></span>}
    </div>
  );
}
