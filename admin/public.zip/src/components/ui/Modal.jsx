import { useEffect, useRef, useId } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { cn } from "../../lib/cn";
import Button from "./Button";

let openCount = 0;
const FOCUSABLE = 'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])';

/** Shared behaviour for Modal + Drawer: Esc to close, scroll lock, focus trap, restore focus. */
function useOverlay({ open, onClose, panelRef }) {
  useEffect(() => {
    if (!open) return undefined;
    const previous = document.activeElement;
    openCount += 1;
    document.body.style.overflow = "hidden";
    const panel = panelRef.current;
    const focusables = () => [...(panel?.querySelectorAll(FOCUSABLE) || [])].filter((el) => !el.closest('[hidden],[aria-hidden="true"],[inert]'));
    (panel?.querySelector("[data-autofocus]") || focusables()[0] || panel)?.focus?.();

    const onKey = (e) => {
      if (e.key === "Escape") { e.stopPropagation(); onClose?.(); return; }
      if (e.key !== "Tab") return;
      const list = focusables();
      if (!list.length) { e.preventDefault(); return; }
      const first = list[0]; const last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      openCount -= 1;
      if (openCount <= 0) { openCount = 0; document.body.style.overflow = ""; }
      previous?.focus?.();
    };
  }, [open, onClose, panelRef]);
}

const WIDTH = { sm: "max-w-sm", md: "max-w-lg", lg: "max-w-2xl", xl: "max-w-4xl", full: "max-w-6xl" };

/**
 * <Modal open onClose title description size="sm|md|lg|xl" footer={<>…</>}>content</Modal>
 * Bottom-sheet on phones, centred dialog from sm up.
 */
export default function Modal({ open, onClose, title, description, size = "md", footer, children, closeOnOverlay = true, className, hideClose }) {
  const panelRef = useRef(null);
  const titleId = useId();
  useOverlay({ open, onClose, panelRef });
  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-4" role="presentation">
      <div className="absolute inset-0 animate-fade-in bg-overlay backdrop-blur-[2px]" onClick={closeOnOverlay ? onClose : undefined} aria-hidden />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? titleId : undefined}
        tabIndex={-1}
        className={cn(
          "relative flex max-h-[92dvh] w-full animate-pop-in flex-col overflow-hidden rounded-t-2xl border border-line bg-surface shadow-pop outline-none sm:max-h-[88dvh] sm:rounded-2xl",
          WIDTH[size], className
        )}
      >
        {(title || !hideClose) && (
          <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
            <div className="min-w-0">
              {title && <h2 id={titleId} className="text-lg font-semibold text-fg">{title}</h2>}
              {description && <p className="mt-0.5 text-sm text-fg-subtle">{description}</p>}
            </div>
            {!hideClose && (
              <button type="button" onClick={onClose} aria-label="Close" className="-mr-1.5 grid size-8 shrink-0 place-items-center rounded-md text-fg-subtle hover:bg-surface-2 hover:text-fg focus-ring">
                <X className="size-4.5" />
              </button>
            )}
          </div>
        )}
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex flex-col-reverse gap-2 border-t border-line bg-surface-2/60 px-5 py-3.5 sm:flex-row sm:justify-end">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

/** Side panel (filters, detail views). side="right|left" */
export function Drawer({ open, onClose, title, description, side = "right", width = "max-w-md", footer, children }) {
  const panelRef = useRef(null);
  const titleId = useId();
  useOverlay({ open, onClose, panelRef });
  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-50" role="presentation">
      <div className="absolute inset-0 animate-fade-in bg-overlay" onClick={onClose} aria-hidden />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? titleId : undefined}
        tabIndex={-1}
        className={cn(
          "absolute inset-y-0 flex w-full flex-col border-line bg-surface shadow-pop outline-none",
          width,
          side === "right" ? "right-0 animate-slide-in-right border-l" : "left-0 animate-slide-in-left border-r"
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
          <div className="min-w-0">
            {title && <h2 id={titleId} className="text-lg font-semibold text-fg">{title}</h2>}
            {description && <p className="mt-0.5 text-sm text-fg-subtle">{description}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="-mr-1.5 grid size-8 shrink-0 place-items-center rounded-md text-fg-subtle hover:bg-surface-2 hover:text-fg focus-ring">
            <X className="size-4.5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-5 py-3.5">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

/** <ConfirmDialog open title="Delete news?" message="…" tone="danger" confirmLabel="Delete" loading onConfirm onClose /> */
export function ConfirmDialog({ open, onClose, onConfirm, title = "Are you sure?", message, confirmLabel = "Confirm", cancelLabel = "Cancel", tone = "primary", loading, children }) {
  return (
    <Modal
      open={open}
      onClose={loading ? undefined : onClose}
      title={title}
      size="sm"
      hideClose
      footer={
        <>
          <Button variant="outline" onClick={onClose} disabled={loading} data-autofocus>{cancelLabel}</Button>
          <Button variant={tone === "danger" ? "danger" : "primary"} onClick={onConfirm} loading={loading}>{confirmLabel}</Button>
        </>
      }
    >
      {message && <p className="text-sm text-fg-muted">{message}</p>}
      {children}
    </Modal>
  );
}
