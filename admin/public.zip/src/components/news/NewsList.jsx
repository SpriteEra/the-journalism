import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Clock, Eye, FilterX, History, Link2, MessageCircle, MoreVertical, Pencil, Plus, Share2, SlidersHorizontal, Trash2, User } from "lucide-react";
import toast from "react-hot-toast";
import httpClient from "../../api/httpClient";
import { useFetchNews } from "../../hooks/news";
import usePermission from "../../hooks/usePermission";
import { useApiMutation } from "../../hooks/admin";
import { fmtDate } from "../../lib/api";
import { handleImageError } from "../../utils/imageError";
import NewsFilter from "../NewsFilter";
import UpdateStackPanel from "../UpdateStack";
import { buttonStyles } from "../ui/Button";
import { Badge, Button, Card, ConfirmDialog, EmptyState, ErrorState, IconButton, Menu, MenuItem, MenuSeparator, PageHeader, Pagination, SearchInput, Skeleton } from "../ui";

const EMPTY = { category: [], subCategory: [], district: "", state: "", location: "", createdAt: "", search: "" };
const countActive = (f) => ["category", "subCategory"].reduce((n, k) => n + (f[k]?.length ? 1 : 0), 0) + ["district", "state", "location", "createdAt"].filter((k) => f[k]).length;

const statusOf = (n, draft) => (draft ? { tone: "neutral", label: "Draft" } : n.need_approval ? { tone: "warning", label: "Needs approval" } : n.isPublished === false ? { tone: "neutral", label: "Unpublished" } : { tone: "success", label: "Published" });

function ShareMenu({ item }) {
  const url = `${import.meta.env.VITE_CLIENT_URL || ""}/news/${item.news_id}`;
  const tags = (item.tags || []).slice(0, 3).map((t) => `#${typeof t === "string" ? t : t.title}`.replace(/\s+/g, "")).join(" ");
  return (
    <Menu trigger={<IconButton label="Share" size="icon-sm"><Share2 className="size-4" /></IconButton>} width="w-48">
      <MenuItem icon={MessageCircle} as="a" href={`https://wa.me/?text=${encodeURIComponent(`*${item.title}*\n${url}\n${tags}`)}`} target="_blank" rel="noreferrer">WhatsApp</MenuItem>
      <MenuItem icon={Link2} onClick={() => navigator.clipboard?.writeText(url).then(() => toast.success("Link copied"))}>Copy link</MenuItem>
    </Menu>
  );
}

/**
 * One list for published news, drafts and the review queue.
 * Permissions: edit = news.update.own / news.update.any, delete = news.delete.own (own, drafts unless can publish) / news.delete.any.
 */
export default function NewsList({ title, description, draft = false, needApproval = false, editQuery = "?mode=edit", editBase = "/dashboard/news/edit-news", emptyText = "No news here yet" }) {
  const navigate = useNavigate();
  const { can, user } = usePermission();
  const [params, setParams] = useSearchParams();
  const page = parseInt(params.get("page") || "1", 10);
  const [limit, setLimit] = useState(10);
  const [selected, setSelected] = useState(EMPTY);
  const [applied, setApplied] = useState(EMPTY);
  const [search, setSearch] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [stack, setStack] = useState(null);

  const { data, isPending, isFetching, isError, error, refetch } = useFetchNews({ page, limit, draft, need_approval: needApproval, filters: applied });
  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, [page]);
  const go = (p) => setParams({ page: p });

  const del = useApiMutation((id) => httpClient.delete(`/delete-news/${id}`).then((r) => r.data), { invalidate: ["news"], success: "News deleted", onSuccess: () => setDeleting(null) });
  const apply = (f) => { setApplied(f); go(1); };
  const active = countActive(applied) + (applied.search ? 1 : 0);

  const canDelete = (n) => can("news.delete.any") || (can("news.delete.own") && String(n.author?._id || n.author?.id) === String(user?.id) && (draft || can("news.publish")));
  const canEdit = () => can("news.update.any") || can("news.update.own");

  return (
    <>
      <PageHeader title={title} description={description}
        actions={can("news.create") && <Link to="/dashboard/news/create" className={buttonStyles({})}><Plus className="size-4" />Write news</Link>} />

      <Card padded={false}>
        <div className="flex flex-col gap-3 border-b border-line p-4 sm:flex-row sm:items-center">
          <form className="w-full sm:max-w-sm" onSubmit={(e) => { e.preventDefault(); apply({ ...selected, search }); }}>
            <SearchInput value={search} onChange={(v) => { setSearch(v); if (!v && applied.search) apply({ ...selected, search: "" }); }} placeholder="Search title, place, category or tag (Enter)" />
          </form>
          <div className="flex flex-wrap items-center gap-2 sm:ml-auto">
            <Badge tone="primary">{(data?.total ?? 0).toLocaleString("en-IN")} {draft ? "drafts" : "stories"}</Badge>
            {active > 0 && <Button variant="ghost" size="sm" leftIcon={FilterX} onClick={() => { setSelected(EMPTY); setSearch(""); apply(EMPTY); }}>Clear {active}</Button>}
            <Button variant="outline" size="sm" leftIcon={SlidersHorizontal} onClick={() => setFilterOpen(true)}>Filters</Button>
          </div>
        </div>

        {isError ? <ErrorState error={error} onRetry={refetch} /> : isPending ? (
          <ul className="divide-y divide-line">{Array.from({ length: 5 }).map((_, i) => <li key={i} className="flex gap-4 p-4"><Skeleton className="h-20 w-32 shrink-0" /><div className="flex-1 space-y-2"><Skeleton className="h-5 w-3/4" /><Skeleton className="h-4 w-1/2" /></div></li>)}</ul>
        ) : !data?.news?.length ? (
          <EmptyState title={emptyText} description={active ? "Try clearing the filters." : undefined} action={!active && can("news.create") ? <Link to="/dashboard/news/create" className={buttonStyles({})}><Plus className="size-4" />Write news</Link> : null} />
        ) : (
          <ul className={`divide-y divide-line transition-opacity ${isFetching ? "opacity-70" : ""}`}>
            {data.news.map((n) => {
              const st = statusOf(n, draft);
              return (
                <li key={n.news_id} className="flex flex-col gap-3 p-4 transition-colors hover:bg-surface-2/50 sm:flex-row sm:gap-4">
                  <Link to={`/dashboard/news/${n.news_id}`} className="block aspect-video w-full shrink-0 overflow-hidden rounded-lg bg-surface-3 sm:h-24 sm:w-40">
                    <img src={`${n.banner}?q=75&w=320`} alt="" loading="lazy" onError={handleImageError} className="size-full object-cover" />
                  </Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start gap-2">
                      <Link to={`/dashboard/news/${n.news_id}`} className="hindi-font line-clamp-2 flex-1 text-base font-semibold text-fg hover:text-primary">{n.title}</Link>
                      <Badge tone={st.tone} dot size="sm" className="shrink-0">{st.label}</Badge>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-fg-subtle">
                      <span className="inline-flex items-center gap-1"><Clock className="size-3.5" />{fmtDate(n.createdAt, true)}</span>
                      {!draft && <span className="inline-flex items-center gap-1"><Eye className="size-3.5" />{(n.activity?.total_reads || 0).toLocaleString("en-IN")}</span>}
                      <span className="inline-flex items-center gap-1"><User className="size-3.5" />@{n.approved_by?.username || n.author?.username}{n.approved_by && <span className="text-fg-faint">(approved)</span>}</span>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {(n.category || []).map((c) => <Badge key={c.slug} tone="primary" size="sm">{c.name}</Badge>)}
                      {(n.state || []).map((s) => <Badge key={s.slug} tone="info" size="sm">{s.displayName || s.state}</Badge>)}
                      {(n.district || []).map((d) => <Badge key={d.slug} tone="info" size="sm">{d.displayName || d.district}</Badge>)}
                      {(n.tags || []).slice(0, 4).map((t) => <Badge key={t.slug} size="sm">#{t.title}</Badge>)}
                      {(n.tags || []).length > 4 && <Badge size="sm" tone="outline">+{n.tags.length - 4}</Badge>}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1 sm:flex-col sm:items-end sm:justify-between">
                    {canEdit() && <Button size="sm" variant={needApproval ? "primary" : "outline"} leftIcon={Pencil} onClick={() => navigate(`${editBase}/${n.news_id}${editQuery}`)}>{needApproval ? "Review" : "Edit"}</Button>}
                    <div className="flex items-center">
                      {!draft && <ShareMenu item={n} />}
                      {(n.update_stack || canDelete(n)) && (
                        <Menu trigger={<IconButton label="More" size="icon-sm"><MoreVertical className="size-4" /></IconButton>} width="w-44">
                          {n.update_stack && <MenuItem icon={History} onClick={() => setStack(n.update_stack)}>History</MenuItem>}
                          {canDelete(n) && <><MenuSeparator /><MenuItem icon={Trash2} tone="danger" onClick={() => setDeleting(n)}>Delete</MenuItem></>}
                        </Menu>
                      )}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        <Pagination page={page} total={data?.total || 0} limit={limit} onPage={go} onLimit={(l) => { setLimit(l); go(1); }} className="border-t border-line" />
      </Card>

      <NewsFilter isOpen={filterOpen} onClose={() => setFilterOpen(false)} selectedOptions={selected} setSelectedOptions={setSelected} handleSubmit={() => apply({ ...selected, search })} />
      <ConfirmDialog open={Boolean(deleting)} onClose={() => setDeleting(null)} tone="danger" loading={del.isPending} onConfirm={() => del.mutate(deleting.news_id)} confirmLabel="Delete" title="Delete this story?" message={deleting ? `“${deleting.title}” moves to the trash.` : ""} />
      <UpdateStackPanel isOpen={Boolean(stack)} onClose={() => setStack(null)} stack_id={stack} />
    </>
  );
}
