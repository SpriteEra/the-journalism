import React, { useContext, useEffect, useState } from "react";
import { toast } from "react-hot-toast";
import { useNavigate, useParams } from "react-router-dom";
// import Section from "./NewsSection.jsx";
import { IoMdClose } from "react-icons/io";
import { IoIosAddCircle } from "react-icons/io";
import { useQueryClient } from "@tanstack/react-query";

// import { CategoryData } from "../assets/CategoryData.js";
import { handleImageError } from "../utils/imageError.js";
import { TagPicker, TaxonomyFields } from "./taxonomy/TaxonomyFields.jsx";
import SchedulePopUp from "./common/SchedulePopUp.jsx";
import Tag from "../utils/Tag.jsx";
import { EditorContext } from "../pages/news/CreateNews.jsx";
import httpClient from "../api/httpClient.js";
import Confirmation from "../utils/Confirmation.jsx";
import InputFields from "../utils/InputFields.jsx";
import { User } from "lucide-react";

import { AITagsButton } from "./keywords/AITagsButton.jsx";
import AITagsPopup from "./keywords/Aitagspopup.jsx";


// for ai tags aiGeneratedTags
const extractTextFromEditorJS = (content) => {
  const blocks = Array.isArray(content) ? content[0]?.blocks : content?.blocks;
  if (!blocks) return "";
  const cleanText = (text = "") => text.replace(/<[^>]*>/g, "").trim();
  return blocks
    .map((block) => {
      switch (block.type) {
        case "paragraph":
        case "header":
        case "quote":
          return cleanText(block.data?.text || "");
        default:
          return "";
      }
    })
    .filter(Boolean)
    .join(" ");
};


function base64ToFile(base64String, fileName) {
  const arr = base64String.split(",");
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], fileName, { type: mime });
}
const timeOptions = [];
for (let i = 0; i < 24; i++) {
  for (let j = 0; j < 60; j += 15) {
    const hour = i % 12 === 0 ? 12 : i % 12;
    const paddedHour = hour.toString().padStart(2, "0"); // Ensures two-digit hour format
    const minute = j === 0 ? "00" : j.toString().padStart(2, "0"); // Ensures two-digit minute format
    const period = i < 12 ? "AM" : "PM";
    timeOptions.push(`${paddedHour}:${minute} ${period}`);
  }
}

const PublishForm = () => {
  const charLength = 400;
  const tagLimit = 15;
  const navigate = useNavigate();
  const { news_id } = useParams();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const query = new URLSearchParams(window.location.search);
  const mode = query.get("mode");
  const type = query.get("type");
  const queryClient = useQueryClient();

  // for ai generate tags
  const [trendingPopupOpen, setTrendingPopupOpen] = useState(false);
  const [aiTagsPopupOpen, setAiTagsPopupOpen] = useState(false);
  const [aiTagsLoading, setAiTagsLoading] = useState(false);

  const [popupOpen, setPopUpOpen] = useState(false);
  // const [scheduleData, setScheduleData] = useState({
  //   date: "",
  //   time: "",
  // });
  let {
    blog: {
      banner,
      title,
      tags,
      description,
      content,
      is_literature,
      category,
      subCategory,
      state,
      district,
      location,
      breaking_news,
      post_time,
      sendNotification,
      imageRef,
      video,
      isVideo,
      ref_reporter,
      aiGeneratedTags,
    },
    setEditorState,
    setBlog,
    blog,
    hasChanges,
    setHasChanges,
    textEditor,
    setTextEditor,
  } = useContext(EditorContext);
  const toggleSwitch = () => {
    setBlog({ ...blog, sendNotification: !sendNotification });
  };

  const [tagdata, setTagData] = useState("");
  const [selectedTimeIndex, setSelectedTimeIndex] = useState(0);

  useEffect(() => {
    const autoSave = () => {
      localStorage.setItem("blog", JSON.stringify(blog));
      setHasChanges(false);
    };

    const intervalId = setInterval(autoSave, 5000);

    return () => clearInterval(intervalId);
  }, [
    description,
    state,
    district,
    category,
    subCategory,
    location,
    hasChanges,
    post_time,
    aiGeneratedTags,
  ]);

  const handleClose = () => {
    setEditorState("editor");
    setHasChanges(true);
    setTextEditor((prev) => ({ ...prev, isReady: false }));
  };

  const handleKeyDown = (e) => {
    setHasChanges(true);
    if (e.keyCode === 13 || e.keyCode === 188) {
      e.preventDefault();
      let tag = e.target.value;
      if (tags?.length < tagLimit) {
        if (!tags.includes(tag) && tag.length) {
          setBlog({ ...blog, tags: [...tags, tag] });
        }
      } else {
        toast.error(`You can add max ${tagLimit} tags`);
      }
      setTagData("");
    }
  };

  // keywords
  // ── Core generate function (reused by first-click and Regenerate) ──────────
  const generateAITags = async () => {
    if (!title && !content) {
      toast.error("Add a title or content first");
      return false;
    }
    setAiTagsLoading(true);
    const loadingToast = toast.loading("Generating tags...");
    try {
      const plainContent = extractTextFromEditorJS(content);
      const { data } = await httpClient.post("/spriteera-service/generate-tags", {
        title,
        content: plainContent,
      });
      const generatedTags = (data.tags || [])
        .map((t) => t.trim().toLowerCase())
        .filter(Boolean);

      if (generatedTags.length === 0) {
        toast.dismiss(loadingToast);
        toast.error("No tags returned, try again");
        return false;
      }

      setBlog({ ...blog, aiGeneratedTags: generatedTags })
      // setAiGeneratedTags(generatedTags); // persisted via useEffect above
      toast.dismiss(loadingToast);
      return true;
    } catch (err) {
      toast.dismiss(loadingToast);
      console.error(err);
      toast.error("Failed to generate tags");
      return false;
    } finally {
      setAiTagsLoading(false);
    }
  };

  // ── Button click: open chooser if pool exists, else generate first ─────────
  const handleAIButtonClick = async () => {
    if (aiGeneratedTags?.length > 0) {
      setAiTagsPopupOpen(true);
      return;
    }
    const success = await generateAITags();
    if (success) setAiTagsPopupOpen(true);
  };

  // ── Regenerate from inside chooser popup ───────────────────────────────────
  const handleRegenerate = async () => {
    await generateAITags();
    // popup stays open; updated aiGeneratedTags re-renders it automatically
  };

  // ── User picks tags from AI pool → merge into news tags ───────────────────
  const handleAddAITags = (selectedTags) => {
    const newTags = selectedTags
      .map((t) => t.toLowerCase())
      .filter((t) => !tags.map((x) => x.toLowerCase()).includes(t));
    const tagsToAdd = newTags.slice(0, tagLimit - tags.length);

    if (tagsToAdd.length === 0) {
      return toast.error("All selected tags already exist or limit reached");
    }

    const updatedBlog = { ...blog, tags: [...tags, ...tagsToAdd] };
    setBlog(updatedBlog);
    localStorage.setItem("blog", JSON.stringify(updatedBlog)); // immediate save
    setHasChanges(true);
    toast.success(`Added ${tagsToAdd.length} tag${tagsToAdd.length > 1 ? "s" : ""}`);
  };

  // ─── Trending Tags ─────────────────────────────────────────────────────────
  const handleAddTrendingTags = (selectedTags) => {
    const newTags = selectedTags.filter((t) => !tags.includes(t));
    const tagsToAdd = newTags.slice(0, tagLimit - tags.length);
    if (tagsToAdd.length === 0) {
      return toast.error("Selected tags already added or limit reached");
    }
    setBlog({ ...blog, tags: [...tags, ...tagsToAdd] });
    setHasChanges(true);
    toast.success(
      tagsToAdd.length < selectedTags.length
        ? `Added ${tagsToAdd.length} tag(s) — some skipped`
        : `Added ${tagsToAdd.length} trending tag${tagsToAdd.length > 1 ? "s" : ""}`
    );
  };
  const handleRemoveAITags = (tagsToRemove) => {
    const removeSet = new Set(tagsToRemove.map(t => t.toLowerCase()));
    const updatedTags = tags.filter(t => !removeSet.has(t.toLowerCase()));
    if (updatedTags.length === tags.length) return; // nothing changed
    const updatedBlog = { ...blog, tags: updatedTags };
    setBlog(updatedBlog);
    localStorage.setItem("blog", JSON.stringify(updatedBlog));
    setHasChanges(true);
    toast.success("AI & trending tags removed");
  };

  // end of ai tags fun


  const handlePublish = (e) => {
    try {
      console.log("Publish clicked");
      // if (e.target.className.includes("disable")) return;
      console.log("Publish clicked");

      // Validation checks
      if (!title.length) {
        return toast.error("Write News Title before publishing");
      }

      if (!description || description.length > charLength) {
        return toast.error(
          `Write a description about your news within ${charLength} characters to publish`
        );
      }

      if (!tags.length || tags.length > tagLimit) {
        return toast.error(
          `Write some tags about news within ${tagLimit} tag limit to publish`
        );
      }

      if (!category?.length) {
        return toast.error("Choose at least one category for the news");
      }

      if (isVideo && !video.length) {
        return toast.error("Please add a video");
      }

      const loadingToast = toast.loading(
        mode === "edit" ? "Updating..." : "Publishing..."
      );

      console.log("Preparing to publish:")
      // Prepare FormData
      const formData = new FormData();
      formData.append("title", title);
      if (banner?.startsWith("data:image")) {
        const bannerFile = base64ToFile(banner, "banner.jpg");
        formData.append("banner", bannerFile);
      } else {
        formData.append("banner", banner); // Image file
      }
      formData.append("video", video); // Image file
      formData.append("imageRef", imageRef); // Image file
      formData.append("isVideo", isVideo); // Image file
      formData.append("description", description);
      formData.append("is_literature", is_literature);
      formData.append("ref_reporter", ref_reporter);
      formData.append("content", JSON.stringify(content));
      formData.append("tags", JSON.stringify(tags)); // Array as JSON string

      // keyword
      formData.append("aiGeneratedTags", JSON.stringify(aiGeneratedTags));
      formData.append("category", JSON.stringify(category || []));
      formData.append("subCategory", JSON.stringify(subCategory || []));
      formData.append("state", JSON.stringify(state || []));
      formData.append("district", JSON.stringify(district || []));
      formData.append("location", location);
      formData.append("breaking_news", breaking_news);
      formData.append("sendNotification", sendNotification);
      formData.append("draft", "false");
      formData.append("id", news_id);
      e.target.classList.add("disable");

      let endpoint = "";
      if (mode === "edit" && type === "guest-news") {
        endpoint = "/publish-guest-news";
      } else if (mode === "edit") endpoint = "/update-news";
      else endpoint = "/create-news";
      httpClient
        .post(endpoint, formData, {
          headers: { "Content-Type": "multipart/form-data" },
        })
        .then(() => {
          e.target.classList.remove("disable");
          toast.dismiss(loadingToast);
          toast.success("Published successfully");
          localStorage.removeItem("blog");
          navigate("/dashboard/news");
          queryClient.invalidateQueries({
            queryKey: ["news"], // Will match all with prefix ['event-news', ...]
          });
        })
        .catch(({ response }) => {
          console.error("Publish failed:", response?.data || response);
          e.target.classList.remove("disable");
          toast.dismiss(loadingToast);
          toast.error(
            response?.data?.error ||
            response?.data?.message ||
            "Failed to publish"
          );
        })
        .finally(() => {
          setIsModalOpen(false);
        });
    }
    catch (err) {
      console.error("Unexpected error during publish:", err);
      toast.error("An unexpected error occurred. Please try again.");
      setIsModalOpen(false);
    }
  };

  const ScheduleNews = () => {
    // if (e.target.className.includes("disable")) return;

    if (!title.length) {
      return toast.error("Write News Title before publishing");
    }
    if (!description || description.length > charLength)
      return toast.error(
        `Write a description about your news within ${charLength} characters to publish`
      );
    if (!tags.length || tags.length > tagLimit) {
      return toast.error(
        ` Write some tags about news within ${tagLimit} tag limit to publish`
      );
    }
    if (!category?.length) {
      return toast.error("Choose at least one category for the news");
    }

    if (!post_time.date) {
      return toast.error("Please select the schedule date");
    }
    if (!post_time.time) {
      return toast.error("Please select the schedule time");
    }

    if (isVideo && !video.length) {
      return toast.error("Please add a video");
    }

    let loadingToast = toast.loading(
      `${mode === "edit" ? "Updating Scheduling News" : "Scheduling News ..."}`
    );

    const formData = new FormData();
    formData.append("title", title);
    if (banner?.startsWith("data:image")) {
      const bannerFile = base64ToFile(banner, "banner.jpg");
      formData.append("banner", bannerFile);
    } else {
      formData.append("banner", banner); // Image file
    }
    formData.append("ref_reporter", ref_reporter);

    formData.append("video", video); // Image file
    formData.append("isVideo", isVideo); // Image file
    formData.append("description", description);
    formData.append("is_literature", is_literature);
    formData.append("content", JSON.stringify(content));
    formData.append("tags", JSON.stringify(tags)); // Array as JSON string


    // keyword
    formData.append("aiGeneratedTags", JSON.stringify(aiGeneratedTags));
    formData.append("category", JSON.stringify(category || []));
    formData.append("subCategory", JSON.stringify(subCategory || []));
    formData.append("state", JSON.stringify(state || []));
    formData.append("district", JSON.stringify(district || []));
    formData.append("location", location);
    formData.append("breaking_news", breaking_news);
    formData.append("sendNotification", sendNotification);
    formData.append("draft", "false");
    formData.append("id", news_id);
    formData.append("post_time", JSON.stringify(post_time));
    // let blogObj = {
    //   title,
    //   banner,
    //   description,
    //   content,
    //   tags,
    //   state,
    //   district,
    //   location,
    //   news_section_type,
    //   breaking_news,
    //   draft: false,
    //   post_time,
    //   sendNotification,
    //   imageRef,
    // };
    // e.target.classList.add("disable");

    let endpoint = "";
    if (mode === "edit") endpoint = "/update-scheduled-news";
    else endpoint = "/create-scheduled-news";

    httpClient
      .post(endpoint, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then(() => {
        // e.target.classList.remove("disable");
        toast.dismiss(loadingToast);
        toast.success(
          `News ${mode === "edit" ? "Updated" : "Scheduled"} successfully`
        );
        localStorage.removeItem("blog");
        navigate("/dashboard/schedule-news");
      })
      .catch(({ response }) => {
        // e.target.classList.remove("disable");
        toast.dismiss(loadingToast);
        return toast.error(
          response?.data?.error ||
          response?.data?.message ||
          "Failed to publish"
        );
      });
  };

  const handleDateChange = (val) => {
    setBlog({
      ...blog,
      post_time: {
        ...blog.post_time,
        date: val,
      },
    });
    setHasChanges(true);
  };

  const handleTimeChange = (selectedIndex) => {
    setSelectedTimeIndex(selectedIndex);
    setBlog({
      ...blog,
      post_time: {
        ...blog.post_time,
        time: timeOptions[selectedIndex],
      },
    });
    setHasChanges(true);
  };

  const handleTag = () => {
    let tag = tagdata;
    setTagData(tag);
    if (tags?.length < tagLimit) {
      if (!tags.includes(tag) && tag.length) {
        setBlog({ ...blog, tags: [...tags, tag] });
      }
    } else {
      toast.error(`You can add max ${tagLimit} tags`);
    }
    setTagData("");
  };

  const handleDescription = (e) => {
    const updatedBlog = { ...blog, description: e.target.value };
    setBlog(updatedBlog);

    // console.log(updatedBlog);

    localStorage.setItem("blog", JSON.stringify(updatedBlog));
  };

  const hasAITags = aiGeneratedTags?.length > 0;
  return (
    <div className="mx-auto sm:p-3 bg-surface rounded-md">
      <div className="flex px-3 mb-4 sticky -top-2 md:-top-6 z-10 bg-primary w-full p-0 sm:p-2 justify-between items-center">
        <p className="text-paper font-medium text-xl md:text-2xl xl:text-2xl mb-1">
          Preview
        </p>
        <button className="w-12 h-12" onClick={handleClose}>
          <IoMdClose
            size={25}
            className="bg-surface rounded-full text-sm text-accent pointer-events-none"
          />
        </button>
      </div>
      <section className="w-full grid grid-cols-1 md:grid-cols-5 lg:gap-4 p-1 sm:p-5">
        <div className="max-w-[400px] center col-span-1 sm:mt-3 md:col-span-2">
          <div className="w-full aspect-video rounded-lg overflow-hidden bg-surface-3 sm:mt-4">
            <img
              src={banner}
              alt="Default Banner"
              className="z-20 rounded-md w-full h-full object-cover"
              onError={handleImageError}
            />
          </div>
          <h2 className="text-2xl font-medium mt-2 leading-tight line-clamp-2">
            {title}
          </h2>
          <p className="line-clamp-3 text-lg leading-7 mt-4">
            {description}
          </p>
        </div>

        <div className="border-line-strong lg:border-1 lg:pl-4 col-span-1 md:col-span-3 h-full md:max-h-[calc(100vh-200px)] lg:max-h-[calc(100vh-190px)] xl:max-h-[calc(100vh-190px)] md:overflow-y-auto md:px-3">
          <div className="sm:py-2 mt-3 sm:mt-5">
            <label className="label">Short description about your news</label>
            <div className="flex flex-col w-[100%] rounded-md bg-surface border border-line-strong">
              <textarea
                maxLength={charLength}
                defaultValue={description}
                className="h-40 resize-none leading-7 input-box sm:pl-4 pl-2"
                placeholder="Enter here short description"
                onChange={handleDescription}
                onKeyDown={(e) => {
                  if (e.keyCode === 13) e.preventDefault();
                }}
              ></textarea>
            </div>
            <p className="mt-1 text-accent text-sm text-right">
              {charLength - description?.length} characters left
            </p>
          </div>



          <div className="mt-3 space-y-2 sm:mt-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-sm text-fg-subtle">Tags help readers and search engines find this story.</span>
              <AITagsButton hasAITags={hasAITags} aiTagsLoading={aiTagsLoading} aiGeneratedTags={aiGeneratedTags} onClick={handleAIButtonClick} />
            </div>
            <TagPicker
              required
              max={tagLimit}
              value={(tags || []).map((t) => ({ title: t }))}
              onChange={(list) => {
                setBlog((prev) => ({ ...prev, tags: list.map((t) => t.title) }));
                setHasChanges(true);
              }}
            />
          </div>
          <div className="flex items-center gap-2 mt-3">
            <input
              type="checkbox"
              checked={is_literature || false} // default false
              onChange={(e) => {
                setBlog({ ...blog, is_literature: e.target.checked });
                setHasChanges(true);
              }}
              className="w-4 h-4 accent-primary"
            />
            <label className="text-sm font-medium">Is it Literature?</label>
          </div>
          {!is_literature && (
            <>
              <div className="sm:py-2 mt-3 sm:mt-5">
                <label className="label">Enter the location of news</label>
                <div className="flex flex-col w-[100%] rounded-md bg-surface border border-line-strong">
                  <input
                    type="text"
                    placeholder="News Location"
                    value={location}
                    className="input-box sm:pl-4 pl-2"
                    onChange={(e) => {
                      setBlog({ ...blog, location: e.target.value });
                      setHasChanges(true);
                    }}
                  />
                </div>
              </div>

            </>
          )}
          <div className="mt-5 pb-2">
            <TaxonomyFields
              value={{ category, subCategory, state, district }}
              onChange={(t) => {
                setBlog((prev) => ({ ...prev, ...t }));
                setHasChanges(true);
              }}
            />
          </div>
          <div className="sm:py-2 mt-3 sm:mt-5">
            <label className="label">Reporter (Optional)</label>
            <div className="flex flex-col w-[100%] rounded-md bg-surface border border-line-strong">
              <input
                type="text"
                placeholder="Enter reporter"
                value={ref_reporter}
                className="input-box sm:pl-4 pl-2"
                onChange={(e) => {
                  setBlog({ ...blog, ref_reporter: e.target.value });
                  setHasChanges(true);
                }}
              />
            </div>
          </div>

          <div className="flex gap-x-5 items-center flex-wrap justify-center w-full my-4">
            <div className="flex items-center justify-evenly gap-3 max-sm:mb-5">
              <p className="text-fg max-sm:text-sm">
                Send Notification
              </p>
              <div
                className={`relative w-16 sm:w-20 h-7 sm:h-10 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-300 ease-in-out ${sendNotification ? "bg-success" : "bg-surface-3"
                  }`}
                onClick={toggleSwitch}
              >
                <span
                  className={`absolute left-8 sm:left-10 right-1 text-paper font-semibold text-sm transition-transform ${sendNotification ? "-translate-x-6 -left-2" : "left-0 "
                    }`}
                >
                  {sendNotification ? "ON" : "OFF"}
                </span>
                <div
                  className={`w-6 sm:w-8 h-6 sm:h-8 bg-surface rounded-full shadow-md transform transition-transform duration-300 ease-in-out ${sendNotification ? "translate-x-8 sm:translate-x-10" : ""
                    }`}
                />
              </div>
            </div>
            <div className="flex gap-3 max-sm:mt-3 max-sm:fixed max-sm:bg-surface-3 max-sm:w-full max-sm:py-2 max-sm:justify-evenly max-sm:bottom-0 max-sm:shadow-xl">
              {type !== "schedule_news" && (
                <button
                  onClick={() => setIsModalOpen(true)}
                  className={`btn-blue md:text-lg `}
                >
                  {mode !== "edit"
                    ? "Publish"
                    : type === "guest-news"
                      ? "Publish"
                      : type === "review"
                        ? "Publish"
                        : "Update"}
                </button>
              )}

              {mode !== "edit" && type !== "guest-news" ? (
                <button
                  onClick={() => setPopUpOpen(true)}
                  className="btn-red md:text-lg"
                >
                  Schedule Post
                </button>
              ) : (
                <> </>
              )}
              {mode === "edit" && type === "schedule_news" ? (
                <button
                  onClick={() => setPopUpOpen(true)}
                  className="btn-red md:text-lg"
                >
                  Update Schedule Post
                </button>
              ) : (
                <> </>
              )}
            </div>
          </div>
        </div>
        {type !== "edit" ? (
          <SchedulePopUp
            popupOpen={popupOpen}
            setPopUpOpen={setPopUpOpen}
            post_time={post_time}
            handleSchedule={ScheduleNews}
            handleDateChange={handleDateChange}
            handleTimeChange={handleTimeChange}
            timeOptions={timeOptions}
            selectedTimeIndex={selectedTimeIndex}
          />
        ) : (
          <> </>
        )}
      </section>
      <Confirmation
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handlePublish}
        btnTitle="Continue"
        title="Are you sure?"
        description="Are you sure you want to perform this action?"
      />
      <AITagsPopup
        isOpen={aiTagsPopupOpen}
        onClose={() => setAiTagsPopupOpen(false)}
        aiGeneratedTags={aiGeneratedTags}
        existingTags={tags || []}
        onAddTags={handleAddAITags}
        onRegenerate={handleRegenerate}
        isRegenerating={aiTagsLoading}
        onRemoveTags={handleRemoveAITags}   // ← add this
      />

    </div>
  );
};

export default PublishForm;
