// TrendsDashboard.jsx
import { useState, useEffect, useCallback } from "react";
import httpClient from "../../api/httpClient";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";

// ── API ───────────────────────────────────────────────────────────────────────
const STALE_6H = 1000 * 60 * 60 * 6;
const STALE_5M = 1000 * 60 * 5;

const fetchTopTrends = async () => {
    const { data } = await httpClient.get("/spriteera-service/top-100-trends");
    return data;
};
const useFetchTopTrends = () =>
    useQuery({
        queryKey: ["top-trends"],
        queryFn: fetchTopTrends,
        staleTime: STALE_6H,
        refetchInterval: STALE_6H,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
    });

const fetchRssFeed = async () => {
    const { data } = await httpClient.get("/spriteera-service/rss");
    return data;
};
const useFetchRssFeed = () =>
    useQuery({
        queryKey: ["rss-feed"],
        queryFn: fetchRssFeed,
        staleTime: STALE_5M,
        refetchInterval: STALE_5M,
        refetchOnWindowFocus: false,
    });

// ── SVG Icons ─────────────────────────────────────────────────────────────────
const ZapIcon = ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg>
);
const TrendingUpIcon = ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" /><polyline points="17 6 23 6 23 12" />
    </svg>
);
const StarIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
);
const RssIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 11a9 9 0 0 1 9 9" /><path d="M4 4a16 16 0 0 1 16 16" /><circle cx="5" cy="19" r="1" fill="currentColor" />
    </svg>
);
const FireIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C8 7 6 10 6 14a6 6 0 0 0 12 0c0-4-2-7-6-12zm0 18a4 4 0 0 1-4-4c0-2.5 1.5-5 4-9 2.5 4 4 6.5 4 9a4 4 0 0 1-4 4z" />
    </svg>
);
const SparkleIcon = ({ size = 12 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.6H22l-6.2 4.5 2.4 7.6L12 17.2l-6.2 4.5 2.4-7.6L2 9.6h7.6z" /></svg>
);
const ExternalIcon = ({ size = 12 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
        <polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
    </svg>
);
const RefreshIcon = ({ size = 15, spinning = false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"
        style={spinning ? { animation: "spin 1s linear infinite" } : {}}>
        <polyline points="23 4 23 10 17 10" />
        <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
    </svg>
);
const ClockIcon = ({ size = 12 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
    </svg>
);
const ChevronRightIcon = ({ size = 12 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="9 18 15 12 9 6" />
    </svg>
);
const ChevronDownIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="6 9 12 15 18 9" />
    </svg>
);
const AlertIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
);
const NewsIcon = ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2" />
        <line x1="18" y1="14" x2="12" y2="14" /><line x1="18" y1="10" x2="12" y2="10" /><line x1="18" y1="18" x2="12" y2="18" />
    </svg>
);

// ── Tag color map ─────────────────────────────────────────────────────────────
const TAG_COLORS = {
    Economy: "bg-success-soft text-success",
    Sports: "bg-primary-soft text-primary",
    Science: "bg-primary-soft text-primary",
    City: "bg-warning-soft text-warning",
    Finance: "bg-warning-soft text-warning",
    Cricket: "bg-danger-soft text-danger",
    Policy: "bg-primary-soft text-primary",
    Weather: "bg-info-soft text-info",
    Politics: "bg-accent-soft text-accent",
    Entertainment: "bg-accent-soft text-accent",
};

const CATEGORY_ALL = "All";

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTimestamp(date) {
    if (!date) return "Never";
    return date.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true }) +
        ", " + date.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}
function getNextRefresh(lastUpdated) {
    if (!lastUpdated) return "—";
    const next = new Date(lastUpdated.getTime() + STALE_6H);
    return next.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true });
}
function timeAgo(dateStr) {
    if (!dateStr) return "";
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
}
function useCountUp(target, duration = 1200) {
    const [val, setVal] = useState(0);
    useEffect(() => {
        let start = 0;
        const step = target / (duration / 16);
        const id = setInterval(() => {
            start += step;
            if (start >= target) { setVal(target); clearInterval(id); }
            else setVal(Math.floor(start));
        }, 16);
        return () => clearInterval(id);
    }, [target, duration]);
    return val;
}

// ── Skeletons ─────────────────────────────────────────────────────────────────
const GoldShimmer = ({ width = "100%", height = 14, rounded = "rounded" }) => (
    <div className={`${rounded} flex-shrink-0`}
        style={{ width, height, background: "linear-gradient(90deg,rgba(245,200,66,0.07) 25%,rgba(245,200,66,0.18) 50%,rgba(245,200,66,0.07) 75%)", backgroundSize: "700px 100%", animation: "shimmer 1.4s ease-in-out infinite" }} />
);
const GrayShimmer = ({ width = "100%", height = 14, rounded = "rounded" }) => (
    <div className={`${rounded}`}
        style={{ width, height, background: "linear-gradient(90deg,var(--line) 25%,var(--surface-2) 50%,var(--line) 75%)", backgroundSize: "700px 100%", animation: "shimmer 1.4s ease-in-out infinite" }} />
);
const Top10SkeletonRow = ({ i }) => (
    <div className="flex items-center gap-4 px-5 py-3.5 border-b border-line last:border-0">
        <GrayShimmer width={32} height={32} rounded="rounded-full" />
        <div className="flex-1 space-y-2">
            <GrayShimmer width={`${55 + (i % 4) * 10}%`} height={12} />
            <GrayShimmer width="80%" height={6} rounded="rounded-full" />
        </div>
        <GrayShimmer width={48} height={20} rounded="rounded-full" />
    </div>
);
const RssSkeletonRow = ({ i }) => (
    <div className="flex items-start gap-4 px-5 py-4 border-b border-line last:border-0">
        <GrayShimmer width={20} height={14} />
        <div className="flex-1 space-y-2">
            <GrayShimmer width={`${70 + (i % 3) * 8}%`} height={13} />
            <div className="flex gap-2">
                <GrayShimmer width={80} height={10} />
                <GrayShimmer width={50} height={10} />
                <GrayShimmer width={55} height={18} rounded="rounded-full" />
            </div>
        </div>
    </div>
);
const ErrorState = ({ message, onRetry }) => (
    <div className="flex flex-col items-center gap-3 py-8 text-center">
        <div className="w-10 h-10 rounded-full bg-danger-soft flex items-center justify-center text-danger">
            <AlertIcon size={18} />
        </div>
        <p className="text-[13px] text-fg-subtle">{message}</p>
        <button onClick={onRetry}
            className="text-[12px] font-semibold px-4 py-1.5 rounded-lg border transition-all hover:opacity-80"
            style={{ borderColor: "rgba(0,0,104,0.25)", color: "var(--main2)", background: "rgba(0,0,104,0.04)" }}>
            Try again
        </button>
    </div>
);

function deriveTop10(trends) {
    return [...trends]
        .sort((a, b) => (b.searchVolume || 0) - (a.searchVolume || 0))
        .slice(0, 10)
        .map((item, idx) => ({
            rank: idx + 1,
            keyword: item.keyword || item.normalizedKeyword || "—",
            score: Math.min(99, Math.round(((item.searchVolume || 0) / (trends[0]?.searchVolume || 1)) * 99)),
            searchVolume: item.searchVolume || 0,
            state: item.state || "IN",
        }));
}

// ── Main Dashboard ─────────────────────────────────────────────────────────────
export default function TrendsDashboard() {
    const [searchQuery, setSearchQuery] = useState("");
    const [activeTab, setActiveTab] = useState("all");
    const [categoryFilter, setCategoryFilter] = useState(CATEGORY_ALL);
    const [lastUpdated, setLastUpdated] = useState(null);
    const [showAllKeywords, setShowAllKeywords] = useState(false); // mobile expand

    const {
        data: trendsData,
        isLoading: trendsLoading,
        isFetching: trendsFetching,
        isError: trendsError,
        refetch: refetchTrends,
        dataUpdatedAt: trendsUpdatedAt,
    } = useFetchTopTrends();

    const {
        data: rssData,
        isLoading: rssLoading,
        isFetching: rssFetching,
        isError: rssError,
        refetch: refetchRss,
    } = useFetchRssFeed();

    useEffect(() => {
        if (trendsUpdatedAt) setLastUpdated(new Date(trendsUpdatedAt));
    }, [trendsUpdatedAt]);

    const allTrends = trendsData?.data?.slice(0, 100)?.map((item) => (item.keyword || "").toLowerCase())?.filter(Boolean) || [];
    const top10 = trendsData?.data ? deriveTop10(trendsData.data) : [];
    const filteredTop10 = top10;
    const rssItems = rssData?.data || [];
    const filtered = allTrends.filter(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const totalCount = useCountUp(allTrends.length);
    const isFetching = trendsFetching || rssFetching;

    // mobile: show 20 by default, all when expanded
    const MOBILE_LIMIT = 20;
    const mobileKeywords = showAllKeywords ? filtered : filtered.slice(0, MOBILE_LIMIT);

    const handleManualRefresh = useCallback(() => {
        refetchTrends();
        refetchRss();
    }, [refetchTrends, refetchRss]);

    return (
        <>
            <style>{`
                :root { --main1: var(--accent); --main2: var(--primary); }
                @keyframes shimmer { 0% { background-position: -700px 0; } 100% { background-position: 700px 0; } }
                @keyframes spin { to { transform: rotate(360deg); } }
                @keyframes goldShimmer { 0% { background-position: -300% center; } 100% { background-position: 300% center; } }
                @keyframes goldGlow { 0%,100% { box-shadow: 0 4px 24px rgba(197,140,10,0.1); } 50% { box-shadow: 0 8px 40px rgba(197,140,10,0.1); } }
                @keyframes dotPulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:0.5; transform:scale(0.7); } }
                @keyframes fadeSlideUp { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
                @keyframes rankPop { 0% { transform:scale(0.8); opacity:0; } 100% { transform:scale(1); opacity:1; } }
                .trend-item { animation: fadeSlideUp 0.35s ease both; }
                .rank-badge { animation: rankPop 0.3s ease both; }
                .ai-block { background: linear-gradient(135deg,var(--gold-ink) 0%,var(--gold-ink) 50%,var(--gold-ink) 100%); animation: goldGlow 10s ease-in-out infinite; }
                .gold-text {
                    background: linear-gradient(105deg,var(--gold-700) 0%,var(--gold-300) 20%,var(--gold-100) 40%,var(--gold-200) 50%,var(--gold-100) 60%,var(--gold-500) 80%,var(--gold-300) 100%);
                    background-size: 300% auto; -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
                    animation: goldShimmer 10s linear infinite;
                }
                .scrollbar-hide::-webkit-scrollbar { display: none; }
                .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
                .admin-card { background: white; border-radius: 12px; border: 1px solid var(--line); }
                .dark .admin-card { background: var(--canvas); border-color: var(--surface); }
                .stat-card { transition: transform 0.15s ease, box-shadow 0.15s ease; }
                .stat-card:hover { transform: translateY(-1px); box-shadow: 0 4px 16px rgba(0,0,0,0.08); }
                .side-panel { max-height: 600px; overflow-y: auto; }
                .side-panel::-webkit-scrollbar { width: 4px; }
                .side-panel::-webkit-scrollbar-track { background: transparent; }
                .side-panel::-webkit-scrollbar-thumb { background: var(--line); border-radius: 2px; }
                .expand-btn { transition: all 0.2s ease; }
                .expand-btn:hover { transform: translateY(1px); }
            `}</style>

            <div className="min-h-screen bg-surface-2 font-sans">

                {/* ── Header ── */}
                <header className="sticky -top-3 sm:-top-6 z-30 bg-surface border-b border-line">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6">
                        <div className="flex items-center justify-between h-14 gap-4">
                            <div className="flex items-center gap-3 min-w-0">
                                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-paper flex-shrink-0" style={{ background: "var(--main2)" }}>
                                    <TrendingUpIcon size={15} />
                                </div>
                                <div className="flex items-center gap-1.5 text-[13px]">
                                    <span className="text-fg-faint hidden sm:inline">Dashboard</span>
                                    <ChevronRightIcon size={11} />
                                    <span className="font-semibold text-fg">Trends Hub</span>
                                </div>
                            </div>
                            <div className="flex items-center gap-3 flex-shrink-0">
                                <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-success-soft border border-success/30">
                                    <span className="w-1.5 h-1.5 rounded-full bg-success" style={{ animation: "dotPulse 1.5s ease-in-out infinite" }} />
                                    <span className="text-[11px] font-semibold text-success">LIVE</span>
                                </div>
                                {/* <div className="hidden md:flex flex-col items-end">
                                    <div className="flex items-center gap-1 text-[11px] text-fg-faint">
                                        <ClockIcon size={11} />
                                        <span>Last updated: <span className="font-medium text-fg-muted">{formatTimestamp(lastUpdated)}</span></span>
                                    </div>
                                    <span className="text-[10px] text-fg-faint">Next refresh: {getNextRefresh(lastUpdated)}</span>
                                </div> */}
                                <button onClick={handleManualRefresh} disabled={isFetching} title="Refresh now"
                                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-semibold border transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-surface-2"
                                    style={{ borderColor: "rgba(0,0,104,0.25)", color: "var(--main2)", background: "rgba(0,0,104,0.04)" }}>
                                    <RefreshIcon size={13} spinning={isFetching} />
                                    <span className="hidden sm:inline">{isFetching ? "Refreshing…" : "Refresh"}</span>
                                </button>
                            </div>
                        </div>
                        <div className="flex md:hidden items-center justify-between pb-2 text-[10px] text-fg-faint">
                            {/* <span className="flex items-center gap-1"><ClockIcon size={10} />Updated: {formatTimestamp(lastUpdated)}</span> */}
                            {/* <span>Next: {getNextRefresh(lastUpdated)}</span> */}
                        </div>
                    </div>
                </header>

                <main className="max-w-7xl mx-auto sm:px-6 py-5 space-y-5">

                    {/* ── AI Premium Block ── */}
                    <section className="ai-block rounded-2xl overflow-hidden border border-warning/30 relative">
                        <div className="h-[2px]" style={{ background: "linear-gradient(90deg,transparent,var(--gold-300),var(--gold-200),var(--gold-300),transparent)" }} />
                        <div className="p-5 sm:p-7 relative">
                            <div className="flex flex-col sm:flex-row sm:items-start gap-5">
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 flex-wrap mb-3">
                                        <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                                            style={{ background: "linear-gradient(135deg,var(--gold-300),var(--gold-500))", boxShadow: "0 2px 12px rgba(197,140,10,0.5)" }}>
                                            <ZapIcon size={16} />
                                        </div>
                                        <h2 className="text-[18px] sm:text-[22px] font-black gold-text tracking-tight">AI Trend Intelligence</h2>
                                        <span className="text-[9px] font-extrabold tracking-widest px-2 py-0.5 rounded-full"
                                            style={{ background: "linear-gradient(105deg,var(--gold-300),var(--gold-200))", color: "var(--gold-ink)" }}>PREMIUM</span>
                                    </div>
                                    <p className="text-[13px] leading-relaxed mb-4" style={{ color: "rgba(253,233,138,0.75)" }}>
                                        Our AI engine continuously scans <span className="font-semibold" style={{ color: "var(--gold-200)" }}>10,000+ sources</span> across
                                        search trends — delivering real-time keyword intelligence so your stories rank before competitors even start writing.
                                    </p>
                                    <div className="flex flex-wrap gap-2 mb-5">
                                        {[
                                            { label: "Keywords generate", val: "For every news" },
                                            { label: "Updated every", val: "6 hours" },
                                            // { label: "Accuracy", val: "94.2%" },
                                            { label: "Languages", val: "Hindi + EN" },
                                        ].map(s => (
                                            <div key={s.label} className="flex flex-col px-3 py-1.5 rounded-lg"
                                                style={{ background: "rgba(245,200,66,0.08)", border: "1px solid rgba(245,200,66,0.2)" }}>
                                                <span className="text-[10px]" style={{ color: "rgba(253,233,138,0.5)" }}>{s.label}</span>
                                                <span className="text-[13px] font-bold" style={{ color: "var(--gold-200)" }}>{s.val}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="sm:w-[220px] flex-shrink-0 rounded-xl p-4"
                                    style={{ background: "rgba(245,200,66,0.05)", border: "1px solid rgba(245,200,66,0.15)" }}>
                                    <p className="text-[10px] font-bold tracking-widest uppercase mb-3" style={{ color: "rgba(253,233,138,0.5)" }}>What you get</p>
                                    {["Real-time trending keywords", "AI-powered tag generation", "Hindi + English support",
                                        "RSS news feed integration", "Ranking score per keyword", "Top 10 high-impact picks"].map((feat, i) => (
                                            <div key={i} className="flex items-start gap-2 mb-2">
                                                <span className="mt-0.5 flex-shrink-0 text-[var(--gold-200)]"><SparkleIcon size={10} /></span>
                                                <span className="text-[11px] leading-snug" style={{ color: "rgba(253,233,138,0.7)" }}>{feat}</span>
                                            </div>
                                        ))}
                                </div>
                            </div>
                        </div>
                    </section>

                    {/* ── Tabs ── */}
                    <div className="flex gap-1 p-1 bg-surface-2 rounded-xl self-start w-fit">
                        {["all", "top10", "rss"].map(tab => (
                            <button key={tab} onClick={() => setActiveTab(tab)}
                                className={`px-4 py-2 rounded-lg text-[12px] font-semibold transition-all duration-150 ${activeTab === tab
                                    ? "bg-surface text-fg shadow-sm"
                                    : "text-fg-subtle hover:text-fg-muted"}`}>
                                {tab === "all" ? "🔥 Top 100" : tab === "top10" ? "⭐ Top 10" : "📡 RSS Feed"}
                            </button>
                        ))}
                    </div>

                    {/* ═══════════════════════════════════════════════════════════
                        DESKTOP: Side-by-side | MOBILE: Stacked
                    ═══════════════════════════════════════════════════════════ */}
                    {(activeTab === "all" || activeTab === "top10") && (
                        <div className={activeTab === "all" ? "flex flex-col lg:flex-row gap-5 items-start" : ""}>

                            {/* ── Left: Top 10 ── */}
                            <section className={`admin-card overflow-hidden ${activeTab === "all" ? "lg:w-[400px] flex-shrink-0 w-full" : "w-full"}`}>
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-line">
                                    <div className="flex items-center gap-2">
                                        <div className="w-7 h-7 rounded-lg flex items-center justify-center text-warning" style={{ background: "rgba(245,158,11,0.1)" }}>
                                            <StarIcon size={13} />
                                        </div>
                                        <h2 className="text-[14px] font-bold text-fg">Top 10 Keywords</h2>
                                        <span className="text-[10px] font-bold tracking-widest px-2 py-0.5 rounded-full text-warning"
                                            style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)" }}>HIGH IMPACT</span>
                                    </div>
                                </div>
                                <div className="divide-y divide-line">
                                    {trendsError ? (
                                        <ErrorState message="Failed to load top keywords." onRetry={refetchTrends} />
                                    ) : trendsLoading ? (
                                        Array.from({ length: 10 }).map((_, i) => <Top10SkeletonRow key={i} i={i} />)
                                    ) : filteredTop10.length === 0 ? (
                                        <p className="text-[13px] text-fg-faint px-5 py-6 text-center">No keywords available.</p>
                                    ) : filteredTop10.map((item, i) => (
                                        <div key={item.rank}
                                            className="trend-item flex items-center gap-4 px-5 py-3.5 hover:bg-surface-2 transition-colors cursor-pointer group"
                                            style={{ animationDelay: `${i * 45}ms` }}>
                                            <div className={`rank-badge w-8 h-8 rounded-full flex items-center justify-center text-[12px] font-black flex-shrink-0 ${item.rank <= 3 ? "text-paper" : "bg-surface-2 text-fg-subtle"}`}
                                                style={item.rank <= 3 ? {
                                                    background: item.rank === 1 ? "linear-gradient(135deg,var(--gold-300),var(--gold-500))" :
                                                        item.rank === 2 ? "linear-gradient(135deg,var(--fg-faint),var(--fg-subtle))" :
                                                            "linear-gradient(135deg,var(--gold-500),var(--gold-700))",
                                                    animationDelay: `${i * 45}ms`
                                                } : { animationDelay: `${i * 45}ms` }}>
                                                {item.rank}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <p className="text-[13px] font-semibold text-fg capitalize truncate">{item.keyword}</p>
                                                    {item.state && item.state !== "IN" && (
                                                        <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full flex-shrink-0 bg-surface-2 text-fg-muted">
                                                            {item.state}
                                                        </span>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <div className="flex-1 h-1.5 rounded-full bg-surface-2 overflow-hidden">
                                                        <div className="h-full rounded-full"
                                                            style={{ width: `${item.score}%`, background: item.rank <= 3 ? "linear-gradient(90deg,var(--gold-300),var(--gold-500))" : "var(--main2)", transition: "width 0.8s ease" }} />
                                                    </div>
                                                    <span className="text-[10px] text-fg-faint font-medium w-6 text-right">{item.score}</span>
                                                </div>
                                            </div>
                                            {item.searchVolume > 0 && (
                                                <span className="text-[11px] font-bold text-success bg-success-soft px-2 py-0.5 rounded-full flex-shrink-0">
                                                    {item.searchVolume >= 1000 ? `${(item.searchVolume / 1000).toFixed(0)}K` : item.searchVolume}
                                                </span>
                                            )}
                                            {item.rank <= 3 && <FireIcon size={14} />}
                                        </div>
                                    ))}
                                </div>
                            </section>

                            {/* ── Right: Top 100 (only in "all" tab) ── */}
                            {activeTab === "all" && (
                                <section className="admin-card overflow-hidden flex-1 w-full">
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-line">
                                        <div className="flex items-center gap-2">
                                            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "rgba(0,0,104,0.08)" }}>
                                                <TrendingUpIcon size={13} />
                                            </div>
                                            <h2 className="text-[14px] font-bold text-fg">Top 100 Trending</h2>
                                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full text-paper" style={{ background: "var(--main1)" }}>LIVE</span>
                                        </div>
                                        <input type="text" placeholder="Search keywords…" value={searchQuery}
                                            onChange={e => { setSearchQuery(e.target.value); setShowAllKeywords(false); }}
                                            className="w-full sm:w-44 pl-3 pr-3 py-1.5 text-[12px] rounded-lg border border-line bg-surface-2 text-fg placeholder-fg-faint focus:outline-none focus:ring-2 focus:border-transparent transition-all" />
                                    </div>

                                    <div className="p-4">
                                        {trendsError ? (
                                            <ErrorState message="Failed to load trending keywords." onRetry={refetchTrends} />
                                        ) : trendsLoading ? (
                                            <div className="flex flex-wrap gap-2">
                                                {Array.from({ length: 40 }).map((_, i) => (
                                                    <GoldShimmer key={i} width={60 + (i % 5) * 18} height={28} rounded="rounded-full" />
                                                ))}
                                            </div>
                                        ) : (
                                            <>
                                                {/* ── Desktop: all keywords in scrollable wrap ── */}
                                                <div className="hidden lg:block side-panel">
                                                    <div className="flex flex-wrap gap-2">
                                                        {filtered.map((tag, i) => {
                                                            const isHot = i < 10;
                                                            return (
                                                                <button key={tag}
                                                                    className="trend-item inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-[11px] font-medium transition-all duration-150 hover:scale-105 active:scale-95 border"
                                                                    style={{
                                                                        animationDelay: `${Math.min(i * 8, 250)}ms`,
                                                                        ...(isHot ? {
                                                                            background: "linear-gradient(105deg,rgba(0,0,104,0.08),rgba(0,0,104,0.04))",
                                                                            borderColor: "rgba(0,0,104,0.3)", color: "var(--main2)",
                                                                        } : {
                                                                            background: "transparent", borderColor: "rgba(0,0,0,0.1)", color: "var(--fg-muted)",
                                                                        })
                                                                    }}>
                                                                    {isHot && <FireIcon size={10} />}
                                                                    #{tag}
                                                                </button>
                                                            );
                                                        })}
                                                    </div>
                                                </div>

                                                {/* ── Mobile: limited + expandable ── */}
                                                <div className="lg:hidden">
                                                    <div className="flex flex-wrap gap-2">
                                                        {mobileKeywords.map((tag, i) => {
                                                            const isHot = i < 10;
                                                            return (
                                                                <button key={tag}
                                                                    className="trend-item inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-[11px] font-medium transition-all duration-150 hover:scale-105 active:scale-95 border"
                                                                    style={{
                                                                        animationDelay: `${Math.min(i * 8, 200)}ms`,
                                                                        ...(isHot ? {
                                                                            background: "linear-gradient(105deg,rgba(0,0,104,0.08),rgba(0,0,104,0.04))",
                                                                            borderColor: "rgba(0,0,104,0.3)", color: "var(--main2)",
                                                                        } : {
                                                                            background: "transparent", borderColor: "rgba(0,0,0,0.1)", color: "var(--fg-muted)",
                                                                        })
                                                                    }}>
                                                                    {isHot && <FireIcon size={10} />}
                                                                    #{tag}
                                                                </button>
                                                            );
                                                        })}
                                                    </div>

                                                    {/* Expand/collapse button */}
                                                    {filtered.length > MOBILE_LIMIT && (
                                                        <button
                                                            onClick={() => setShowAllKeywords(v => !v)}
                                                            className="expand-btn mt-4 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-[12px] font-semibold border transition-all"
                                                            style={{ borderColor: "rgba(0,0,104,0.2)", color: "var(--main2)", background: "rgba(0,0,104,0.03)" }}>
                                                            <span>{showAllKeywords ? "Show less" : `Show ${filtered.length - MOBILE_LIMIT} more keywords`}</span>
                                                            <span style={{ transform: showAllKeywords ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s ease", display: "inline-flex" }}>
                                                                <ChevronDownIcon size={14} />
                                                            </span>
                                                        </button>
                                                    )}
                                                </div>
                                            </>
                                        )}

                                        {filtered.length === 0 && !trendsLoading && !trendsError && (
                                            <p className="text-[13px] text-fg-faint py-6 text-center">No keywords match your search.</p>
                                        )}

                                        {!trendsError && (
                                            <div className="flex items-center justify-between mt-4 pt-3 border-t border-line">
                                                <span className="text-[11px] text-fg-faint">
                                                    Showing <strong>{filtered.length}</strong> of <strong>{allTrends.length}</strong> keywords
                                                </span>
                                                <span className="text-[11px] text-fg-faint flex items-center gap-1">
                                                    <ClockIcon size={10} />Refreshes every 6h
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                </section>
                            )}
                        </div>
                    )}

                    {/* ── RSS Feed ── */}
                    {(activeTab === "all" || activeTab === "rss") && (
                        <section className="admin-card overflow-hidden">
                            <div className="flex items-center justify-between px-5 py-4 border-b border-line">
                                <div className="flex items-center gap-2">
                                    <div className="w-7 h-7 rounded-lg flex items-center justify-center text-paper flex-shrink-0" style={{ background: "var(--main1)" }}>
                                        <RssIcon size={13} />
                                    </div>
                                    <h2 className="text-[14px] font-bold text-fg">Top RSS News Feed</h2>
                                </div>
                                <span className="text-[10px] text-fg-faint font-medium">Story suggestions</span>
                            </div>

                            <div className="divide-y divide-line">
                                {rssError ? (
                                    <ErrorState message="Failed to load RSS feed." onRetry={refetchRss} />
                                ) : rssLoading ? (
                                    Array.from({ length: 6 }).map((_, i) => <RssSkeletonRow key={i} i={i} />)
                                ) : rssItems.length === 0 ? (
                                    <p className="text-[13px] text-fg-faint px-5 py-6 text-center">No RSS items available.</p>
                                ) : rssItems.map((item, i) => (
                                    <div
                                        key={item._id || i}
                                        className="trend-item"
                                        style={{ animationDelay: `${i * 55}ms` }}
                                    >
                                        {/* ── Topic Header ── */}
                                        <div className="flex items-start gap-3 px-4 py-4 sm:px-5">
                                            {/* Index badge — mobile gets its own styled pill */}
                                            <div className="flex-shrink-0 w-6 h-6 sm:w-auto sm:h-auto rounded-full sm:rounded-none flex items-center justify-center sm:block"
                                            >
                                                <span className="text-[11px] sm:text-[13px] font-black text-fg-faint sm:text-fg-muted sm:w-5 sm:text-right sm:mt-0.5 leading-none sm:leading-normal"
                                                >
                                                    {i + 1}
                                                </span>
                                            </div>

                                            <div className="flex-1 min-w-0">
                                                {/* Title — dark and bold for visibility */}
                                                <p className="text-[14px] sm:text-[15px] font-bold leading-snug mb-2"
                                                    style={{ color: "var(--canvas)" }}>
                                                    {item.title}
                                                </p>

                                                {/* Meta row */}
                                                <div className="flex items-center gap-2 flex-wrap">
                                                    {item.state && (
                                                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${TAG_COLORS["City"] || "bg-surface-2 text-fg-muted"}`}>
                                                            {item.state}
                                                        </span>
                                                    )}
                                                    {item.searchVolume > 0 && (
                                                        <span className="text-[10px] font-semibold text-success bg-success-soft px-2 py-0.5 rounded-full border border-success/30">
                                                            {item.searchVolume >= 1000
                                                                ? `${(item.searchVolume / 1000).toFixed(0)}K searches`
                                                                : `${item.searchVolume} searches`}
                                                        </span>
                                                    )}
                                                    {(item.pubDate || item.capturedAt) && (
                                                        <span className="text-fg-faint text-[10px]">·</span>
                                                    )}
                                                    {item.pubDate && (
                                                        <span className="text-[11px] text-fg-subtle font-medium">{timeAgo(item.pubDate)}</span>
                                                    )}
                                                    {!item.pubDate && item.capturedAt && (
                                                        <span className="text-[11px] text-fg-subtle font-medium">{timeAgo(item.capturedAt)}</span>
                                                    )}
                                                    {item.news?.length > 0 && (
                                                        <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-fg-faint">
                                                            <NewsIcon size={10} />
                                                            {item.news.length} {item.news.length === 1 ? "article" : "articles"}
                                                        </span>
                                                    )}
                                                </div>

                                                {/* Mobile: article count pill */}
                                                {item.news?.length > 0 && (
                                                    <div className="sm:hidden mt-2">
                                                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full"
                                                            style={{ background: "rgba(0,0,104,0.07)", color: "var(--main2)" }}>
                                                            <NewsIcon size={9} />
                                                            {item.news.length} {item.news.length === 1 ? "article" : "articles"}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>

                                        {/* ── Expanded News Cards ── */}
                                        {item.news && item.news.length > 0 && (
                                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 border-t border-line">
                                                {item.news.map((n, ni) => (
                                                    <a
                                                        key={ni}
                                                        href={n.url || "#"}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="group flex flex-row sm:flex-col border-b sm:border-r border-line sm:last:border-r-0 hover:bg-primary-soft/40 transition-colors"
                                                        style={{ textDecoration: "none" }}
                                                    >
                                                        {/* Mobile: thumbnail left, content right */}
                                                        {n.picture ? (
                                                            <div className="w-[90px] sm:w-full h-[70px] sm:h-[130px] overflow-hidden bg-surface-2 flex-shrink-0">
                                                                <img
                                                                    src={n.picture}
                                                                    alt={n.title}
                                                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                                                    onError={(e) => {
                                                                        e.currentTarget.parentElement.innerHTML =
                                                                            `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:22px;color:var(--line-strong);background:var(--surface-2);">📰</div>`;
                                                                    }}
                                                                />
                                                            </div>
                                                        ) : (
                                                            <div className="w-[90px] sm:w-full h-[70px] sm:h-[130px] flex items-center justify-center bg-surface-2 flex-shrink-0 text-fg-faint">
                                                                <RssIcon size={24} />
                                                            </div>
                                                        )}

                                                        {/* Card Body */}
                                                        <div className="flex flex-col gap-1 p-3 flex-1 min-w-0">
                                                            {n.source && (
                                                                <span className="text-[10px] font-bold uppercase tracking-wider truncate" style={{ color: "var(--main2)" }}>
                                                                    {n.source}
                                                                </span>
                                                            )}
                                                            <p className="text-[12px] sm:text-[12px] font-semibold leading-snug flex-1 group-hover:text-primary transition-colors"
                                                                style={{
                                                                    color: "var(--surface)",
                                                                    display: "-webkit-box",
                                                                    WebkitLineClamp: 3,
                                                                    WebkitBoxOrient: "vertical",
                                                                    overflow: "hidden",
                                                                }}>
                                                                {n.title || "Untitled"}
                                                            </p>
                                                            {n.url && (
                                                                <div className="flex items-center gap-1 mt-auto pt-1 text-[10px] text-fg-faint group-hover:text-primary transition-colors">
                                                                    <ExternalIcon size={9} />
                                                                    <span>Read article</span>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </a>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                            {!rssError && (
                                <div className="px-5 py-3 border-t border-line flex items-center justify-between bg-surface-2/50 justify-end">
                                    {/* <p className="text-[11px] text-fg-faint flex items-center gap-1">
                                        <ClockIcon size={10} /> Updated every 5 minutes · {rssItems.length} items
                                    </p> */}
                                    <Link to={'https://trends.google.com/trending?geo=IN'} target="__blank" className="text-[11px] font-semibold hover:opacity-80 transition-opacity" style={{ color: "var(--main2)" }}>
                                        View all sources →
                                    </Link>
                                </div>
                            )}
                        </section>
                    )}

                    {/* ── Footer ── */}
                    <div className="flex flex-wrap items-center justify-between gap-3 py-3 text-[11px] text-fg-faint border-t border-line">
                        <span>Data refreshes automatically every <strong className="text-fg-subtle">6 hours</strong>. No reload needed on page change.</span>
                        {/* <span className="flex items-center gap-1"><ClockIcon size={10} />Last sync: {formatTimestamp(lastUpdated)}</span> */}
                    </div>
                </main>
            </div>
        </>
    );
}