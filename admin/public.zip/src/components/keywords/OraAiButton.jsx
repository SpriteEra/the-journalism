// TrendingTagsButton.tsx
import { useNavigate } from "react-router-dom";

const CrownIcon = ({ size = 18 }) => (
  <svg
    width={size}
    height={(size * 16) / 18}
    viewBox="0 0 18 16"
    fill="none"
    style={{ flexShrink: 0, filter: "drop-shadow(0 1px 1px rgba(180,100,0,0.4))" }}
  >
    <path
      d="M1 13h16M2 13L1 5l4 4 4-6 4 6 4-4-1 8H2z"
      stroke="var(--gold-ink)"
      strokeWidth="1.6"
      strokeLinejoin="round"
      fill="rgba(61,34,0,0.15)"
    />
    <circle cx="1" cy="5" r="1.2" fill="var(--gold-ink)" />
    <circle cx="9" cy="3" r="1.2" fill="var(--gold-ink)" />
    <circle cx="17" cy="5" r="1.2" fill="var(--gold-ink)" />
  </svg>
);

const TrendingTagsButton = () => {
  const navigate = useNavigate();

  return (
    <>
      <style>{`
        @keyframes goldShift {
          0%, 100% { background-position: 0% center; }
          50%       { background-position: 100% center; }
        }
        @keyframes premiumShimmer {
          0%   { transform: translateX(-100%) skewX(-15deg); }
          100% { transform: translateX(350%)  skewX(-15deg); }
        }
        @keyframes outerGlow {
          0%, 100% { opacity: 0.5; }
          50%      { opacity: 1;   }
        }
        @keyframes crownFloat {
          0%, 100% { transform: translateY(0px);   }
          50%      { transform: translateY(-1.5px); }
        }
        .premium-btn {
          
          transform: scale(1.04);
          background-size: 300% auto;
        //   animation: goldShift 3s ease-in-out infinite;
          text-shadow: 0 1px 0 rgba(255,230,100,0.6);
          outline: none;
          transition: transform 0.12s ease;
          -webkit-tap-highlight-color: transparent;
        }
        .premium-btn::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: 12px;
          background: linear-gradient(105deg, var(--gold-500), var(--gold-200), var(--gold-500));
          z-index: -1;
        //   animation: outerGlow 3s ease-in-out infinite;
          filter: blur(4px);
          transform: scale(1.04);s
        }
        /* ── YouTube-style shimmer sweep ── */
        .premium-btn::after {
          content: '';
          position: absolute;
          top: 0; left: 0;
          width: 40%;
          height: 100%;
          background: linear-gradient(
            105deg,
            transparent 0%,
            rgba(255,255,255,0.08) 30%,
            rgba(255,255,255,0.55) 50%,
            rgba(255,255,255,0.08) 70%,
            transparent 100%
          );
          transform: scale(1.04);
          animation: premiumShimmer 2.4s ease-in-out infinite;
          pointer-events: none;
        }
        .premium-btn:hover  { transform: scale(1.04); }
        .premium-btn:active { transform: scale(0.97); }
        .crown-icon { animation: crownFloat 2.4s ease-in-out infinite; }
        .btn-gloss-top {
          position: absolute;
          top: 0; left: 10%; right: 10%;
          height: 45%;
          background: linear-gradient(to bottom, rgba(255,255,255,0.22), transparent);
          border-radius: 0 0 50% 50%;
          pointer-events: none;
        }
        .btn-gloss-bottom {
          position: absolute;
          bottom: 0; left: 10%; right: 10%;
          height: 30%;
          background: linear-gradient(to top, rgba(0,0,0,0.12), transparent);
          pointer-events: none;
        }
      `}</style>

      <button
        className="premium-btn relative flex items-center gap-3 px-3 sm:px-5 py-2 sm:py-2 rounded-full border-none cursor-pointer text-xs sm:text-[15px] font-semibold tracking-[0.04em] text-[var(--gold-ink)] overflow-hidden"
        onClick={() => navigate("/dashboard/ora-ai")}
      >
        <span className="btn-gloss-top" aria-hidden />
        {/* <span className="btn-gloss-bottom" aria-hidden /> */}
        <CrownIcon className="crown-icon" />
        <span>Ora News AI</span>
      </button>
    </>
  );
};

export default TrendingTagsButton;