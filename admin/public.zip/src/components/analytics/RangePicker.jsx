import { useState } from "react";
import { Button, Input, Select } from "../ui";

const istDay = (d) => new Date(d.getTime() + 5.5 * 3600000).toISOString().slice(0, 10);
export const rangeFromDays = (days) => ({ from: istDay(new Date(Date.now() - (days - 1) * 86400000)), to: istDay(new Date()) });

/** Preset (7 / 30 / 90 / 365 days) or custom from–to. onChange({from,to}) with YYYY-MM-DD (IST). */
export default function RangePicker({ value, onChange }) {
  const [preset, setPreset] = useState("30");
  const [custom, setCustom] = useState(value);
  return (
    <div className="flex flex-wrap items-end gap-2">
      <div className="w-40">
        <Select size="sm" aria-label="Date range" value={preset} onChange={(e) => { setPreset(e.target.value); if (e.target.value !== "custom") onChange(rangeFromDays(Number(e.target.value))); }}
          options={[{ value: "7", label: "Last 7 days" }, { value: "30", label: "Last 30 days" }, { value: "90", label: "Last 90 days" }, { value: "365", label: "Last 12 months" }, { value: "custom", label: "Custom range" }]} />
      </div>
      {preset === "custom" && (
        <>
          <Input size="sm" type="date" aria-label="From" className="h-9 w-40" value={custom.from} max={custom.to} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
          <Input size="sm" type="date" aria-label="To" className="h-9 w-40" value={custom.to} min={custom.from} onChange={(e) => setCustom({ ...custom, to: e.target.value })} />
          <Button size="sm" onClick={() => custom.from && custom.to && onChange(custom)}>Apply</Button>
        </>
      )}
    </div>
  );
}
