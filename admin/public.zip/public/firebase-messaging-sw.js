importScripts("https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js");
importScripts(
    "https://www.gstatic.com/firebasejs/8.10.1/firebase-messaging.js"
);

// Replace these with your own Firebase config keys...
const firebaseConfig = {
    apiKey: "AIzaSyAJjWngAN7g3eOLBBtafthga1SCvrKtNRY",
    authDomain: "janpadnewstimes-d2eb4.firebaseapp.com",
    projectId: "janpadnewstimes-d2eb4",
    storageBucket: "janpadnewstimes-d2eb4.firebasestorage.app",
    messagingSenderId: "228931912040",
    appId: "1:228931912040:web:27c22afbfdd8a7cd1f96dd",
    measurementId: "G-Q2N5Z7SJJ6"
};


firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
    // console.log(
    //     "[firebase-messaging-sw.js] Received background message ",
    //     payload
    // );

    // payload.fcmOptions?.link comes from our backend API route handle
    // payload.data.link comes from the Firebase Console where link is the 'key'
    const link = payload.fcmOptions?.link || payload.data?.url;

    self.registration.showNotification(payload.notification.title, {
        body: payload.notification.body,
        icon: "/favicon.ico",
        data: { url: link },
    });
});

self.addEventListener("notificationclick", function (event) {
    const url = event.notification?.data?.url;
    event.notification.close();

    if (!url) return;

    event.waitUntil(
        clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
            for (const client of clientList) {
                if (client.url === url && "focus" in client) {
                    return client.focus();
                }
            }
            if (clients.openWindow) {
                return clients.openWindow(url);
            }
        })
    );
});
