import { createUser, getMyProfile, updateMyProfile, getNotificationPreferences, getUser, logOut, login, sendDemoNotification, updateFCM, updateNotificationPreference, updatePassword } from '../controller/user.controller.js'
import { handleRefreshToken } from '../middleware/handleRefreshToken.js';
import { authorizeroles, isAuthenticated } from '../middleware/Authentication.js';


export default userRoute;

async function userRoute(app) {
    app.post('/sign-up', createUser);
    app.post('/sign-in', login);
    app.get('/me', { onRequest: [isAuthenticated] }, getUser);
    app.get('/profile', { onRequest: [isAuthenticated] }, getMyProfile);
    app.put('/profile', { onRequest: [isAuthenticated] }, updateMyProfile);
    app.post('/log-out', { onRequest: [isAuthenticated] }, logOut);
    app.put('/update-password', { onRequest: [isAuthenticated] }, updatePassword);
    app.get('/refresh-token', handleRefreshToken);
    app.put('/update-fcm', { onRequest: [isAuthenticated] }, updateFCM);
    app.get('/send-notification', { onRequest: [isAuthenticated, authorizeroles('admin')] }, sendDemoNotification);
    app.post("/update-notification-preference", { onRequest: [isAuthenticated] }, updateNotificationPreference);
    app.get("/notification-preferences", { onRequest: [isAuthenticated] }, getNotificationPreferences);
}
